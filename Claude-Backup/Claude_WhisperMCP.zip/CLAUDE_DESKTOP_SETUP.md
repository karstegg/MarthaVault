# Whisper MCP Setup for Claude Desktop

Complete step-by-step instructions to configure Whisper MCP server in Claude Desktop.

## Prerequisites

- Claude Desktop installed
- OpenAI API key (for GPT-4o audio models)
- `uv` package manager installed
- `mcp-server-whisper` cloned/available locally

## Step 1: Get Your OpenAI API Key

1. Go to https://platform.openai.com/api/keys
2. Create a new API key (or use existing)
3. Copy the key (starts with `sk-proj-`)
4. **Keep this safe** - you'll need it in the config

## Step 2: Create/Update Claude Desktop MCP Config

Claude Desktop stores its MCP configuration in:
```
C:\Users\[YourUsername]\AppData\Local\Claude\claude_desktop_config.json
```

Or if that doesn't exist, create it at:
```
C:\Users\10064957\AppData\Local\Claude\claude_desktop_config.json
```

## Step 3: Add Whisper to Config (IMPORTANT SECTION)

Open the file and add the whisper server. Here's the complete config:

```json
{
  "mcpServers": {
    "whisper": {
      "command": "uvx",
      "args": [
        "--from",
        "C:/Users/10064957/.claude/mcp-servers/mcp-server-whisper",
        "mcp-server-whisper"
      ],
      "env": {
        "OPENAI_API_KEY": "sk-proj-YOUR_API_KEY_HERE",
        "AUDIO_FILES_PATH": "C:/Users/10064957/My Drive/GDVault/MarthaVault/media/audio"
      }
    }
  }
}
```

## Step 4: Key Configuration Details

### Command vs Args

**Option A: Using `uvx` (Recommended for development)**
```json
{
  "command": "uvx",
  "args": [
    "--from",
    "C:/Users/10064957/.claude/mcp-servers/mcp-server-whisper",
    "mcp-server-whisper"
  ]
}
```
- Runs directly from source directory
- Good for testing/development
- Requires `uv` installed

**Option B: Using `python` (If uvx fails)**
```json
{
  "command": "python",
  "args": [
    "C:/Users/10064957/.claude/mcp-servers/mcp-server-whisper/server.py"
  ]
}
```
- Runs Python script directly
- May need dependencies installed separately

## Step 5: Environment Variables (CRITICAL)

The `env` section is **required** for Whisper to work:

```json
"env": {
  "OPENAI_API_KEY": "sk-proj-YOUR_API_KEY_HERE",
  "AUDIO_FILES_PATH": "C:/Users/10064957/My Drive/GDVault/MarthaVault/media/audio"
}
```

**OPENAI_API_KEY**:
- Required: YES
- Must start with: `sk-proj-`
- Where to get: https://platform.openai.com/api/keys
- Security: Keep confidential

**AUDIO_FILES_PATH**:
- Required: YES
- Must use forward slashes: `/` not `\`
- Path must exist before using transcribe functions
- Folder: `media/audio` in your vault

## Step 6: Restart Claude Desktop

After updating the config:

1. **Completely close** Claude Desktop (not just minimize)
2. Wait 3 seconds
3. Reopen Claude Desktop
4. Check Tools panel - Whisper should appear

## Step 7: Verify Installation

In Claude Desktop, check if Whisper functions appear:

- `transcribe_audio` - Basic transcription
- `transcribe_with_enhancement` - Enhanced (detailed/professional/analytical)
- `create_audio` - Text-to-speech
- `convert_audio` - Format conversion
- `compress_audio` - File compression
- `chat_with_audio` - Audio conversation

If you see these tools, **setup is successful!**

## Troubleshooting

### Problem: "Whisper server failed to connect"

**Solution 1: Check uvx is installed**
```bash
uv --version
```
Should output version info. If not, install:
```bash
pip install uv
```

**Solution 2: Check Python path**
If using Python approach:
```bash
python --version
```
Should be 3.8+

**Solution 3: Try alternative command**
Change from `uvx` to `python` approach in config

### Problem: "OPENAI_API_KEY not found"

**Solution:**
1. Verify API key is in config (between quotes)
2. Check key starts with `sk-proj-`
3. Verify it's NOT expired at https://platform.openai.com/api/keys
4. Restart Claude Desktop completely

### Problem: "AUDIO_FILES_PATH not found"

**Solution:**
1. Create folder if missing:
   ```bash
   mkdir "C:\Users\10064957\My Drive\GDVault\MarthaVault\media\audio"
   ```
2. Verify path uses forward slashes `/` in config (not backslashes)
3. Restart Claude Desktop

### Problem: Transcription fails with "File not found"

**Solution:**
- Audio files MUST be in `C:/Users/10064957/My Drive/GDVault/MarthaVault/media/audio`
- Use exact filename from that folder
- Check folder exists and has files

### Problem: "mcp-server-whisper not found"

**Solution:**
- Verify directory exists: `C:\Users\10064957\.claude\mcp-servers\mcp-server-whisper\`
- Check for `server.py` or `__main__.py` in that folder
- If missing, download/clone the repository

## Full Configuration Example

Here's a complete working `.claude/mcp-servers/mcp-server-whisper/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "whisper": {
      "command": "uvx",
      "args": [
        "--from",
        "C:/Users/10064957/.claude/mcp-servers/mcp-server-whisper",
        "mcp-server-whisper"
      ],
      "env": {
        "OPENAI_API_KEY": "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",
        "AUDIO_FILES_PATH": "C:/Users/10064957/My Drive/GDVault/MarthaVault/media/audio"
      }
    }
  }
}
```

## Next Steps

Once Whisper is running in Claude Desktop:

1. **Test transcription**: Upload an audio file to `media/audio/` folder
2. **Use in conversations**: Ask Claude to transcribe files by name
3. **Combine with skills**: Use `/transcribe-voice-notes` skill for batch processing
4. **Check logs**: If issues persist, check Claude Desktop logs in:
   - `C:\Users\10064957\AppData\Local\Claude\logs\`

## Security Notes

- **NEVER** commit API key to git
- **NEVER** share config file with others
- **STORE KEY SAFELY**: Consider using environment variable instead
- **ROTATE REGULARLY**: Change API key every 90 days

### Using Environment Variable (Advanced)

Instead of hardcoding the key:

```json
"env": {
  "OPENAI_API_KEY": "${OPENAI_API_KEY}",
  "AUDIO_FILES_PATH": "C:/Users/10064957/My Drive/GDVault/MarthaVault/media/audio"
}
```

Then set system environment variable:
```bash
setx OPENAI_API_KEY "sk-proj-YOUR_KEY_HERE"
```

Restart computer for changes to take effect.

## Support Resources

- **Whisper Documentation**: https://platform.openai.com/docs/api-reference/audio
- **Claude Desktop Docs**: https://support.anthropic.com/en/articles/8784670
- **MCP Spec**: https://modelcontextprotocol.io/
- **Your Local Config**: `C:\Users\10064957\.mcp.json`

## Quick Start Checklist

- [ ] OpenAI API key obtained
- [ ] claude_desktop_config.json created/updated
- [ ] Whisper server config added with proper paths
- [ ] OPENAI_API_KEY set (not placeholder)
- [ ] AUDIO_FILES_PATH folder exists
- [ ] Claude Desktop restarted
- [ ] Whisper tools visible in Tools panel
- [ ] Test file placed in `media/audio/`
- [ ] Transcription tested successfully
