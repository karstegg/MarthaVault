#!/usr/bin/env python3
"""
Simple script to download attachments from specific Outlook emails
"""

import sys
import os

try:
    import win32com.client
except ImportError:
    print("ERROR: pywin32 not installed. Run: pip install pywin32 --upgrade", file=sys.stderr)
    sys.exit(1)

def download_attachment_from_email(sender_name, subject_contains, download_path):
    """Download attachment from email matching sender and subject"""

    try:
        # Connect to Outlook
        outlook = win32com.client.GetActiveObject("Outlook.Application")
        namespace = outlook.GetNamespace("MAPI")
        inbox = namespace.GetDefaultFolder(6)  # 6 = Inbox

        print(f"✓ Connected to Outlook")

        # Search for email from specific sender
        items = inbox.Items
        items.Sort("[ReceivedTime]", False)  # Sort by received time, descending

        found_count = 0
        for item in items:
            try:
                # Check if email matches criteria
                if hasattr(item, 'SenderName') and hasattr(item, 'Subject'):
                    if sender_name.lower() in item.SenderName.lower() and subject_contains.lower() in item.Subject.lower():
                        print(f"Found email: {item.Subject}")
                        print(f"From: {item.SenderName}")
                        print(f"Attachments: {item.Attachments.Count}")

                        # Download attachments
                        if item.Attachments.Count > 0:
                            for attachment in item.Attachments:
                                filename = attachment.FileName
                                filepath = os.path.join(download_path, filename)

                                print(f"  Downloading: {filename}")
                                attachment.SaveAsFile(filepath)
                                print(f"  ✓ Saved to: {filepath}")
                                found_count += 1
                        else:
                            print("  No attachments found")

                        return True
            except Exception as e:
                # Skip items that cause issues
                continue

        if found_count == 0:
            print(f"✗ No email found from '{sender_name}' with subject containing '{subject_contains}'")
            return False

    except Exception as e:
        print(f"✗ Error: {e}", file=sys.stderr)
        return False

if __name__ == "__main__":
    # Download from Fanele's belt splicing email
    download_path = r"C:\Users\10064957\My Drive\GDVault\MarthaVault\00_Inbox"

    success = download_attachment_from_email(
        sender_name="Fanele Mpofana",
        subject_contains="belt splicing",
        download_path=download_path
    )

    sys.exit(0 if success else 1)
