# Log to Google Sheets Command

You are helping the user log data to their Google Sheets using a custom Python script.

## Instructions:
1. Parse the user's input to extract relevant fields for the history tracking system
2. Execute the Python script located at: `C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\sheets_writer.py`
3. Use the extracted information to populate the Google Sheet

## Expected fields to extract:
- **subject**: Main topic/title of the entry
- **fileName**: Audio file name (if mentioned)
- **transcription**: Initial transcription text (if provided)
- **summary**: Brief summary of the content
- **options**: Tags or options (priority level, type, etc.)

## Usage Examples:
- `/log-to-sheets Weekly team meeting discussed project timeline and resource allocation`
- `/log-to-sheets Client presentation about new dashboard features - high priority`
- `/log-to-sheets Code review session found optimization opportunities in data processing`

## Script Execution:
When processing the user's input, run the Python script with appropriate arguments:

```bash
python "C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\sheets_writer.py" --subject "extracted subject" --summary "extracted summary" --options "extracted options"
```

Or use JSON format for complex data:
```bash
python "C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\sheets_writer.py" --json '{"subject":"subject","summary":"summary","options":"tags"}'
```

## Response:
After successfully executing the script, confirm to the user that the data has been logged to their Google Sheet.