# Weekly Report Email Sources - Quick Reference

**Last Updated:** November 24, 2025
**Scope:** All 5 weekly mining engineering reports for Black Rock operations

---

## Email Source Matrix

| Report | Sender Name | Email Address | Outlook Folder | Subject Keywords | Typical Arrival | Search Window | Notes |
|--------|-------------|---|---|---|---|---|---|
| **N2** | Sikelela Nzuza | Sikelela.Nzuza@assmang.co.za | \Production\NCH2 | "weekly report", "eng report", "nch2", "n2" | Fri-Mon | 4 days | Exclude: "mobilaris", "re:", "fwd:" |
| **N3** | Sello Sease | Sello.Sease@assmang.co.za | \Production\NCH3 | "weekly report", "eng report", "nch3", "n3" | Fri-Mon | 4 days | Standard search |
| **Gloria** | Sipho Dubazane | Sipho.Dubazane@assmang.co.za | \Production\Gloria | "weekly report", "eng report", "gloria" | Fri-Mon | 4 days | Standard search |
| **Shafts & Winders** | Xavier Petersen | Xavier.Petersen@assmang.co.za | \Production\Shaft | "weekly report", "shafts", "winders", "s&w" | Fri-Mon | 4 days | Standard search |
| **Epiroc BEV** | Phillip Moller | phillip.moller@epiroc.com | \OEMs\Epiroc | "weekly report", "brmo", "bev" | **Monday 07:09 AM** | Fri-Mon | **CRITICAL:** PDF marked as inline - may skip in standard filtering |

---

## Detailed Notes

### N2 Report (Sikelela Nzuza)
- **Location:** \Inbox\Production\NCH2
- **Expected Filename:** `Nch2 Weekly Report [DD Mon YYYY].xlsx`
- **What To Look For:** Engineering Report (Excel with equipment availability data)
- **Common Issues:** May receive "RE: NCH2 Mobilaris Report" emails - exclude these
- **Exclude Keywords:** "mobilaris", "re:", "fwd:" (to avoid system issue threads)
- **Contact:** Sikelela.Nzuza@assmang.co.za

### N3 Report (Sello Sease)
- **Location:** \Inbox\Production\NCH3
- **Expected Filename:** `N3 Eng Report Week [XX] [dates].xlsx`
- **What To Look For:** Weekly Engineering Report with equipment and BEV data
- **Typical Attachments:** 2-3 files (Excel report + PPTX HEAL page)
- **Contact:** Sello.Sease@assmang.co.za

### Gloria Report (Sipho Dubazane)
- **Location:** \Inbox\Production\Gloria
- **Expected Filename:** `Gloria Eng Report Week [XX] [dates].xlsx`
- **What To Look For:** Engineering Report with equipment availability
- **Typical Attachments:** 2-3 files (Excel report + PPTX HEAL page)
- **Contact:** Sipho.Dubazane@assmang.co.za

### Shafts & Winders Report (Xavier Petersen)
- **Location:** \Inbox\Production\Shaft
- **Expected Filename:** `Weekly Report Shafts and Winders 2025_[WK]_[dates].xlsx`
- **What To Look For:** Production and availability metrics for shaft/winder systems
- **Typical Attachments:** 2-3 files (Excel + PPTX HEAL page)
- **Contact:** Xavier.Petersen@assmang.co.za
- **Note:** Xavier also sends S2 project updates - look for "Shafts" or "Winders" keywords

### Epiroc BEV Report (Phillip Moller) ⚠️
- **Location:** \Inbox\OEMs\Epiroc (note: plural "OEMs")
- **Expected Filename:** `BRMO weekly report [start date] - [end date].pdf`
- **What To Look For:** Weekly service report covering battery, charger, and BEV status
- **Typical Size:** ~395KB PDF
- **Arrival Time:** **CONSISTENTLY 07:09 AM MONDAY** (SAST)
- **Critical Issue:** PDF often marked as "inline" attachment by Outlook
  - Standard filtering may skip it as "inline image"
  - Workaround: Use manual COM API for unfiltered download
- **Contents:**
  - General Summary
  - BEV Daily Exceptions (equipment breakdowns/delays by day)
  - Planned Work & Maintenance Schedule
  - Battery Status Report with equipment table
  - Battery Overheat Report
  - Critical Issues (BEV, CAS L9, Certiq & Mobilaris)
- **Contact:** phillip.moller@epiroc.com
- **Escalation:** If not found by 9:00 AM Monday, contact Phillip directly

---

## Search Strategy

### Standard Weekly Search (N2, N3, Gloria, S&W)
1. Search folders: \Production\NCH2, \Production\NCH3, \Production\Gloria, \Production\Shaft
2. Date range: Friday of report week through Monday of following week
3. Subject keywords: "weekly report" OR "eng report" OR site-specific term
4. Sender: Match name OR email address (case-insensitive)
5. Apply exclude keywords if applicable

### Epiroc-Specific Search
1. Folder: \OEMs\Epiroc
2. Date range: Friday through Monday (same as others)
3. Subject: Must contain "weekly report"
4. Sender: Must be Phillip Moller
5. **IMPORTANT:** Verify PDF was actually downloaded (don't rely on "Skipped inline" messages)

---

## Troubleshooting Flowchart

### Email Not Found
1. Check correct week number (Week X = July 1 + 7X days)
2. Verify Outlook folder structure matches reference above
3. Try broader date range (extend to Tuesday if Monday search fails)
4. Search email body if subject keyword doesn't match
5. Contact sender directly if >24 hours overdue

### Attachment Not Downloaded
1. Check for "Copy of" prefix (Outlook adds for duplicates)
2. For N2/N3/Gloria/S&W: Close/reopen Outlook and retry skill
3. For Epiroc: Check if PDF marked as "inline" - use manual COM API download
4. Verify Week XX folder exists before attempting download
5. Check file permissions on Week XX folder

### Wrong Email Downloaded
1. N2: Verify not "RE: NCH2 Mobilaris Report" (exclude this)
2. Check sender name/email matches reference table exactly
3. Compare subject to expected format
4. If wrong file, manually delete from Week folder and re-run search

---

## Best Practices

✅ **DO:**
- Check email arrival time against reference (helps identify issues early)
- Verify all attachments downloaded (PDF for Epiroc especially)
- Keep this reference updated as patterns change
- Escalate to sender if >4 hours overdue from typical time
- Save this reference in team shared folder

❌ **DON'T:**
- Assume folder structure matches other weeks (Excel layouts vary)
- Ignore "Skipped inline image" messages for Epiroc (it might be the PDF!)
- Try downloading files > 2 hours after sender reports sent them
- Assume "Copy of" filename is wrong (it's normal for Outlook)
- Delete week folder before confirming all files extracted

---

## Contact Information

**For Report Issues:**
- **N2:** Sikelela Nzuza - Sikelela.Nzuza@assmang.co.za
- **N3:** Sello Sease - Sello.Sease@assmang.co.za
- **Gloria:** Sipho Dubazane - Sipho.Dubazane@assmang.co.za
- **Shafts & Winders:** Xavier Petersen - Xavier.Petersen@assmang.co.za
- **Epiroc BEV:** Phillip Moller - phillip.moller@epiroc.com

**For Outlook/IT Issues:**
- Contact your IT department or Outlook administrator

---

## Revision History

| Date | Change | Notes |
|------|--------|-------|
| 2025-11-24 | Initial creation | Week 21 findings |
| | | Epiroc attachment issue documented |
| | | Email source matrix created |

---

**Next Review:** Week 22 (to validate Epiroc attachment fix and any new patterns)
