# Change Log - Weekly Report Setup Skill

## 2026-02-01

### Changed
- **N2 Weekly Report Sender Updated**
  - Old: Sikelela Nzuza <Sikelela.Nzuza@assmang.co.za>
  - New: Masigcinane Mteki <Masigcinane.Mteki@assmang.co.za>
  - Reason: N2 Weekly Report no longer comes from Sikelela Nzuza; Masigcinane Mteki is the new sender

## 2025-XX-XX

### Initial Implementation
- Skill created to automate steps 1-5 of weekly report generation
- Supports N2, N3, Gloria, S&W, and Epiroc BEV reports
- Uses Outlook COM API for email retrieval
- Fiscal calendar starting July 1, 2025 (Week 1)
