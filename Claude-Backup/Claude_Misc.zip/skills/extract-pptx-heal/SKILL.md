---
name: Extract HEAL Text from PowerPoint
description: Extract HEAL matrix content from PowerPoint slides and save as formatted text files matching N2 HEAL format
---

# Extract HEAL Text from PowerPoint

## When to Use This Skill

Use this skill to extract HEAL content (Highlights, Emerging Issues, Lowlights, Priorities, Actions) from PowerPoint presentations and save them as properly formatted text files. Works with both:
- **Table-based layouts** (Gloria, Shafts & Winders)
- **Section-based layouts** (future variations)

## Usage

### Via Slash Command (Recommended)

```bash
/extract-pptx-heal gloria 16
/extract-pptx-heal shafts-winders 16
/extract-pptx-heal n3 16
```

### Via CLI

```bash
python extract_pptx_heal.py gloria 16
python extract_pptx_heal.py shafts-winders 16
python extract_pptx_heal.py --site=gloria --week=16
```

## Arguments

- **site**: `gloria`, `shafts-winders`, or `n3` (required)
- **week**: Week number (e.g., 16) (required)

## Prerequisites

- Python 3.10+
- `python-pptx` library (may not be installed globally)
- PPTX file located in `Week {N}/` directory matching naming convention

**Alternative Method (No Dependencies)**:
If `python-pptx` is not available, use Python's built-in `zipfile` module to extract text directly from PPTX XML. See "Alternative Extraction Method" section below.

## What This Skill Does

### Data Extraction

The script:
1. **Locates** the PPTX file in `Week {N}/` directory
2. **Parses** table and text structures to identify HEAL sections
3. **Extracts** content under each section header
4. **Organizes** items into standard HEAL categories:
   - Highlights
   - Lowlights
   - Emerging Issues
   - Priorities
   - Actions (if present)
5. **Formats** output with bullet points and section headings
6. **Validates** that content was successfully extracted

### Output Files

The script creates a single text file:

**Format**: `{Site} HEAL Page Week{N}.txt`

**Examples**:
- `Gloria HEAL Page Week16.txt`
- `Shafts and Winders HEAL Page Week16.txt`
- `N3 HEAL Page Week16.txt`

**Location**: `Week {N}/` directory (same as source PPTX)

## CSV Structure & Content

**File Format**: Plain text with line-numbered entries

**Structure**:
```
Highlights
• Item 1
• Item 2

Lowlights
• Item 1

Emerging Issues
• Item 1

Priorities
• Item 1
• Item 2

Actions
• Item 1
```

**Line Numbers**: Read tool displays automatically (e.g., "1→", "2→")

**Section Detection**:
- **Gloria**: 4x2 table layout (Highlights/Lowlights in left/right columns)
- **Shafts & Winders**: Separate tables per section with headers
- **N3**: Detected from file structure

## Site-Specific Data Locations

### Gloria
- **File**: `HEAL page (003).pptx - AutoRecovered.pptx` (or latest HEAL page PPTX)
- **Table Layout**: 4 rows x 2 columns
  - Row 0: Headers (Highlight | Lowlight)
  - Row 1: Content (Highlights left | Lowlights right)
  - Row 2: Headers (Emerging Issues | Priorities)
  - Row 3: Content (Emerging left | Priorities right)

### Shafts & Winders
- **File**: `SHAFTS AND WINDERS_HEAL_{N}_WEEK_*.pptx`
- **Table Layout**: Multiple single-cell tables, one per section
- **Sections**: Headers in first line (e.g., "Highlights:", "Emerging Issues:")

### N3
- **File**: `N3 HEAL Page*.pptx` (pending)
- **Note**: Currently outstanding; script will process when available

## Example Outputs

### Gloria Week 16
```
Highlights
• TMM availability increase from 82% to 86%
• DT0152 transported safely to Broncho
• DT0106 transmission was replaced safely

Lowlights
• DT availability 71%
• DT0152 Line boring
• DT0105 Nerospec

Emerging Issues

Priorities
• Steel cord belt splice scanning...
• Stabilis to submit proposal...
```

### Shafts & Winders Week 16
```
Highlights
• WTFitter Team repaired hot water issue at Nch3 B-Level
• BM Team replaced bolts on guides at Bunton

Emerging Issues
• Low compliment of Fitters and Riggers
• Massive impact of providing Changehouses maintenance

Lowlights
• Positions taking considerable time to fill

Priorities
• Shaft Repair Work with Solrock Team
• Employee Engagement/Resignations
```

## Validation Checks

The script performs these quality checks:

- ✓ PPTX file exists and is readable
- ✓ Content extracted contains expected HEAL sections
- ✓ No empty sections (validates data presence)
- ✓ Output file created successfully
- ✓ All items include bullet points

## Common Issues & Troubleshooting

| Issue | Solution |
|-------|----------|
| "File not found" error | Check PPTX file is in `Week {N}/` directory with correct naming |
| Empty sections extracted | Verify PPTX table structure matches expected layout; check for formatting differences |
| Encoding errors | Script uses UTF-8; ensure Windows locale supports special characters |
| Partial content extracted | Some PPTX files have mixed layouts; verify table structure in SKILL documentation |

## Alternative Extraction Method (No Dependencies)

**Week 31 Discovery**: If `python-pptx` module is not available, use Python's built-in `zipfile` and `xml.etree.ElementTree` to extract text directly from PowerPoint XML structure.

### Method

PowerPoint .pptx files are ZIP archives containing XML files. Extract text using:

```python
import zipfile
import xml.etree.ElementTree as ET

def extract_all_text_recursive(element, ns):
    """Recursively extract all text from an element"""
    texts = []
    for t in element.findall('.//a:t', ns):
        if t.text:
            texts.append(t.text)
    return texts

pptx_file = "HEAL page (002).pptx"

with zipfile.ZipFile(pptx_file, 'r') as z:
    # List all slides
    files = z.namelist()
    slide_files = [f for f in files if f.startswith('ppt/slides/slide') and f.endswith('.xml')]
    slide_files.sort()

    ns = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
          'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}

    for slide_file in slide_files:
        slide_xml = z.read(slide_file)
        slide_root = ET.fromstring(slide_xml)

        # Extract all text elements
        all_texts = extract_all_text_recursive(slide_root, ns)

        # Print extracted text (post-process to organize into HEAL sections)
        for text in all_texts:
            print(text)
```

### Post-Processing

After extraction, organize text into HEAL sections:
1. Identify section headers (Highlights, Lowlights, Emerging Issues, Priorities)
2. Group bullet points under each section
3. Format with standard bullet character (•)
4. Save to `{Site} HEAL Page Week{N}.txt`

### Tested Scenarios (Week 31)

- ✅ **Gloria HEAL**: `HEAL page (002).pptx` - Successfully extracted 4 sections
- ✅ **N3 HEAL**: `Heal N3 week 23 - 29 Jan 2026.pptx` - Successfully extracted with safety incidents, compliance improvements
- ✅ **Shafts & Winders**: Verified against existing PowerPoint source

## Next Steps After Extraction

1. **Review** the generated text file for accuracy
2. **Compare** with source PPTX slides visually if needed
3. **Use** in report generation workflow
4. **Archive** in Week folder for audit trail

## Notes

- N2 HEAL content is typically already in text format (manual entry)
- ✅ **N3 PPTX extraction** successfully tested in Week 31
- Future weeks can use this skill without modification
- Supports both table-based and section-based PowerPoint layouts
- **Alternative zipfile method** requires no external dependencies and works reliably
