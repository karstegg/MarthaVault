#!/usr/bin/env python3
"""
Extract Utility Vehicle Breakdown Details from N3 Daily Excel Reports

Processes 5 daily Excel files (Mon-Fri) and generates:
1. Comprehensive weekly breakdown CSV (all unavailable units)
2. Current status CSV (Friday only - ongoing breakdowns)

Usage:
    python extract_utility_breakdowns.py 31
    python extract_utility_breakdowns.py --week=31
"""

import zipfile
import xml.etree.ElementTree as ET
import csv
import os
import sys
import argparse
from collections import defaultdict
from pathlib import Path


def get_column_letter(cell_ref):
    """Extract column letter from cell reference like 'A1'"""
    return ''.join(c for c in cell_ref if c.isalpha())


def extract_breakdown_data(excel_file, date_str):
    """
    Extract breakdown data from a single Excel file

    Returns list of breakdown dictionaries with fields:
    - Date, Area_Owner, TMM_No, Model, Status, Remarks, OEM_Assistance
    """
    breakdowns = []

    try:
        with zipfile.ZipFile(excel_file, 'r') as z:
            # Read shared strings
            shared_strings_xml = z.read('xl/sharedStrings.xml')
            shared_root = ET.fromstring(shared_strings_xml)
            strings = [
                elem.text if elem.text else ''
                for elem in shared_root.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
            ]

            # Read first sheet
            sheet_xml = z.read('xl/worksheets/sheet1.xml')
            sheet_root = ET.fromstring(sheet_xml)

            # Get all rows
            rows = sheet_root.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')

            # Process data rows (skip header rows 1 and 2, start from row 3)
            for row in rows[2:]:
                row_num = row.get('r')

                # Build cells dictionary
                cells_dict = {}
                for cell in row.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
                    cell_ref = cell.get('r')
                    col_letter = get_column_letter(cell_ref)
                    cell_type = cell.get('t')
                    value_elem = cell.find('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')

                    if value_elem is not None:
                        if cell_type == 's':  # String from shared strings
                            string_idx = int(value_elem.text)
                            value = strings[string_idx] if string_idx < len(strings) else ''
                        else:
                            value = value_elem.text
                        cells_dict[col_letter] = value

                # Extract data from expected columns
                area_owner = cells_dict.get('B', '').strip()
                model = cells_dict.get('C', '').strip()
                tmm_no = cells_dict.get('D', '').strip()
                status = cells_dict.get('E', '').strip()
                remarks = cells_dict.get('F', '').strip()
                oem_assistance = cells_dict.get('G', '').strip()

                # Only include "Not Available" items with TMM numbers
                if status == "Not Available" and tmm_no:
                    breakdowns.append({
                        'Date': date_str,
                        'Area_Owner': area_owner,
                        'TMM_No': tmm_no,
                        'Model': model,
                        'Status': status,
                        'Remarks': remarks,
                        'OEM_Assistance': oem_assistance
                    })

    except Exception as e:
        print(f"Error processing {excel_file}: {e}", file=sys.stderr)
        return []

    return breakdowns


def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(
        description='Extract utility vehicle breakdown data from N3 daily Excel reports'
    )
    parser.add_argument(
        'week',
        type=int,
        nargs='?',
        help='Week number (e.g., 31)'
    )
    parser.add_argument(
        '--week',
        type=int,
        dest='week_arg',
        help='Week number (alternative syntax)'
    )

    args = parser.parse_args()

    # Determine week number
    week = args.week or args.week_arg
    if not week:
        print("Error: Week number is required", file=sys.stderr)
        print("Usage: python extract_utility_breakdowns.py 31", file=sys.stderr)
        print("   or: python extract_utility_breakdowns.py --week=31", file=sys.stderr)
        sys.exit(1)

    # Get base directory (assumes script is in skills folder)
    script_dir = Path(__file__).parent
    reports_base = script_dir.parent.parent.parent / "Weekly Reports"
    week_dir = reports_base / f"Week {week}"
    utility_dir = week_dir / "N3 Utility Performance"

    # Verify directories exist
    if not week_dir.exists():
        print(f"Error: Week {week} folder not found: {week_dir}", file=sys.stderr)
        sys.exit(1)

    if not utility_dir.exists():
        print(f"Error: N3 Utility Performance folder not found: {utility_dir}", file=sys.stderr)
        sys.exit(1)

    # File mappings (note: "Breakdwon" typo is intentional from source system)
    files = [
        ('Breakdwon report - Utility Section 26-01-2026.xlsx', 'Monday 26-01-2026'),
        ('Breakdwon report - Utility Section 27-01-2026.xlsx', 'Tuesday 27-01-2026'),
        ('Breakdwon report - Utility Section 28-01-2026.xlsx', 'Wednesday 28-01-2026'),
        ('Breakdwon report - Utility Section 29-01-2026.xlsx', 'Thursday 29-01-2026'),
        ('Breakdwon report - Utility Section 30-01-2026.xlsx', 'Friday 30-01-2026'),
    ]

    all_breakdowns = []
    friday_breakdowns = []

    print(f"Processing Week {week} utility vehicle breakdowns...")
    print(f"Source directory: {utility_dir}")
    print("=" * 80)

    # Process each file
    for filename, date_str in files:
        filepath = utility_dir / filename

        if not filepath.exists():
            print(f"Warning: {filename} not found, skipping...", file=sys.stderr)
            continue

        print(f"Processing {filename}...")
        breakdowns = extract_breakdown_data(str(filepath), date_str)
        all_breakdowns.extend(breakdowns)

        # Keep Friday data separate for current status file
        if 'Friday' in date_str:
            friday_breakdowns = breakdowns

        print(f"  Found {len(breakdowns)} breakdowns")

    print("=" * 80)

    if not all_breakdowns:
        print("Warning: No breakdowns found in any file!", file=sys.stderr)
        sys.exit(1)

    # Write comprehensive breakdown file (Slide 15)
    all_output_file = week_dir / f'Utility_Section_All_Breakdowns_Week{week}.csv'
    with open(all_output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(
            f,
            fieldnames=['Date', 'Area_Owner', 'TMM_No', 'Model', 'Status', 'Remarks', 'OEM_Assistance']
        )
        writer.writeheader()
        writer.writerows(all_breakdowns)

    print(f"\nCreated: {all_output_file.name}")
    print(f"  Total breakdowns for the week: {len(all_breakdowns)}")

    # Write Friday-only breakdown file (Slide 16)
    friday_output_file = week_dir / f'Utility_Section_Current_Status_Week{week}.csv'
    with open(friday_output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(
            f,
            fieldnames=['Date', 'Area_Owner', 'TMM_No', 'Model', 'Status', 'Remarks', 'OEM_Assistance']
        )
        writer.writeheader()
        writer.writerows(friday_breakdowns)

    print(f"\nCreated: {friday_output_file.name}")
    print(f"  Current breakdowns (Friday): {len(friday_breakdowns)}")

    # Summary by area
    print("\n" + "=" * 80)
    print("BREAKDOWN SUMMARY BY AREA (All Week)")
    print("=" * 80)
    area_counts = defaultdict(int)
    for bd in all_breakdowns:
        area = bd['Area_Owner']
        if area:
            area_counts[area] += 1

    for area in sorted(area_counts.keys()):
        print(f"  {area:20s}: {area_counts[area]} breakdown(s)")

    print("\nExtraction complete!")
    return 0


if __name__ == '__main__':
    sys.exit(main())
