# Extract Utility Breakdowns - Technical Reference

## Implementation Details

This skill extracts detailed breakdown information from N3 Utility Performance daily Excel reports. Unlike the `extract-utility-vehicles` skill which generates availability summary data, this skill focuses on breakdown details for unavailable units.

### Core Logic

1. **Excel File Processing**: Opens each Excel file as a ZIP archive (XLSX format)
2. **Shared Strings Extraction**: Reads `xl/sharedStrings.xml` for text values
3. **Worksheet Parsing**: Processes `xl/worksheets/sheet1.xml` for cell data
4. **Row Filtering**: Extracts only rows where Column E = "Not Available"
5. **Data Compilation**: Combines all 5 days into comprehensive dataset
6. **Dual Output**: Generates both full week and Friday-only CSVs

### File Detection

**Expected File Pattern**:
```
Week N/N3 Utility Performance/Breakdwon report - Utility Section DD-MM-YYYY.xlsx
```

**Note**: "Breakdwon" spelling is intentional (source system typo)

**Hardcoded Dates** (for Week 31 pattern):
- Monday: 26-01-2026
- Tuesday: 27-01-2026
- Wednesday: 28-01-2026
- Thursday: 29-01-2026
- Friday: 30-01-2026

**Future Enhancement**: Auto-detect dates based on week number calculation

### Sheet Structure

**Excel Layout**:
```
Row 1: Header with date (e.g., "30/01/2025 DAY SHIFT REPORT")
Row 2: Column headers
Row 3+: Data rows
```

**Column Mapping**:
| Column | Field | Usage |
|--------|-------|-------|
| A | No | Row number (ignored) |
| B | Area / Owner | Department name |
| C | Equip model | Equipment model description |
| D | TMM No. | Equipment identifier (required) |
| E | Description - EOS / Breakdown | Status filter |
| F | Remaks /Comment | Breakdown details |
| G | OEM Assistance Required / Waiting Parts | External support |
| J-L | Summary columns | Ignored for breakdown extraction |

### Data Extraction Process

**Step 1: XML Namespace Handling**
```python
# Namespace for Excel XML files
ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
```

**Step 2: Cell Value Resolution**
```python
if cell_type == 's':  # String reference
    string_idx = int(value_elem.text)
    value = strings[string_idx]
else:  # Direct value
    value = value_elem.text
```

**Step 3: Row Filtering Logic**
```python
# Only extract if:
# 1. Status is "Not Available"
# 2. TMM_No is not blank
if status == "Not Available" and tmm_no:
    breakdowns.append(...)
```

**Step 4: Friday Isolation**
```python
if 'Friday' in date_str:
    friday_breakdowns = breakdowns
```

### Variation Handling

**TMM Number Formats**:
- **LD prefix**: Light Duty vehicles (LD0272, LD0405, LD0645)
- **UV prefix**: Utility Vehicles (UV0071, UV0078, UV0091)
- **BB prefix**: Bobcats (BB0002, BB0006)

**Status Values**:
- "Available" → Ignored
- "Not Available" → Extracted
- Blank → Ignored

**Area/Owner Variations**:
- Single word: "Ambulance", "BEV", "Security"
- Two words: "Plant Fitter", "Hyd Fitter", "Main West"
- May contain trailing spaces (stripped)

### Known Issues & Workarounds

**Issue 1: Filename Typo**
- **Problem**: Source system generates "Breakdwon" instead of "Breakdown"
- **Workaround**: Script uses exact filename with typo
- **Status**: Permanent (cannot change source system)

**Issue 2: Hardcoded Dates**
- **Problem**: Date patterns assume specific week structure
- **Impact**: Script needs adjustment for different weeks
- **Future Fix**: Calculate dates from week number + start date

**Issue 3: Empty Cells**
- **Problem**: Some rows have missing data in columns B, C, F, G
- **Workaround**: Use `.get()` with empty string default
- **Impact**: None - gracefully handles missing data

**Issue 4: Unicode Console Encoding**
- **Problem**: Windows console can't display checkmark (✓) characters
- **Impact**: Cosmetic only - files created successfully
- **Workaround**: Use `try-except` for print statements with Unicode

### CSV Output Format

**Field Specifications**:

| Field | Type | Max Length | Required | Notes |
|-------|------|------------|----------|-------|
| Date | String | 20 | Yes | Format: "Day DD-MM-YYYY" |
| Area_Owner | String | 50 | Yes | Department name |
| TMM_No | String | 10 | Yes | Equipment ID (LD/UV/BB prefix) |
| Model | String | 100 | Yes | Equipment model description |
| Status | String | 20 | Yes | Always "Not Available" |
| Remarks | String | 500 | No | Breakdown description |
| OEM_Assistance | String | 200 | No | External support notes |

**Encoding**: UTF-8 with BOM
**Line Endings**: CRLF (Windows)
**Quote Character**: Double quote (")
**Delimiter**: Comma (,)

### Performance Characteristics

**Processing Time** (typical):
- Single Excel file: ~0.5 seconds
- All 5 files: ~2.5 seconds
- Total execution: ~3 seconds (including CSV writes)

**Memory Usage**:
- Peak: ~50 MB (loading shared strings + XML parsing)
- Average: ~20 MB
- Minimal impact even on low-spec systems

**File Sizes**:
- Input Excel: ~29 KB each (5 files = 145 KB)
- Output All Breakdowns CSV: ~5-7 KB (~40-50 rows)
- Output Current Status CSV: ~1-2 KB (~5-10 rows)

### Testing Coverage

**Verified Scenarios**:
- ✅ Week 31 (5 files, 43 total breakdowns, 7 Friday breakdowns)
- ✅ Missing file handling (graceful skip with warning)
- ✅ Empty breakdown list (error message, exit code 1)
- ✅ Unicode encoding in remarks (handled correctly)

**Edge Cases Tested**:
- Empty TMM_No field (skipped)
- Missing OEM_Assistance column (empty string)
- Trailing spaces in Area_Owner (stripped)
- Mixed status values in same file (filtered correctly)

### Future Enhancements

**Priority 1: Dynamic Date Detection**
```python
# Calculate dates based on week number
week_start = get_week_start_date(week_number)
dates = [(week_start + timedelta(days=i)).strftime('%d-%m-%Y') for i in range(5)]
```

**Priority 2: Glob Pattern Matching**
```python
# Find files with any date pattern
excel_files = list(utility_dir.glob('Breakdwon report - Utility Section *.xlsx'))
excel_files.sort()  # Process in chronological order
```

**Priority 3: Breakdown Duration Parsing**
```python
# Extract time ranges from remarks (e.g., "10:45 - EOS")
def parse_breakdown_duration(remarks):
    pattern = r'(\d{1,2}:\d{2})\s*-\s*(EOS|\d{1,2}:\d{2})'
    # Calculate hours of downtime
```

**Priority 4: Equipment Type Categorization**
```python
# Auto-categorize by TMM prefix
def get_equipment_category(tmm_no):
    if tmm_no.startswith('LD'):
        return 'Light Duty Vehicle'
    elif tmm_no.startswith('UV'):
        return 'Utility Vehicle'
    elif tmm_no.startswith('BB'):
        return 'Bobcat'
```

### Integration with Report Generation

**Workflow Position**: Phase 1 - Data Extraction (Step 5)

**Dependencies**:
- Requires: Week N folder created
- Requires: N3 Utility Performance subfolder with 5 Excel files
- Used by: Slide 15 (All Breakdowns table)
- Used by: Slide 16 (Current Status table)
- Complements: extract-utility-vehicles (Slide 14 availability data)

**Output Consumed By**:
- `html-generator` agent (converts CSV to HTML tables)
- `pdf-exporter` agent (renders final PDF slides)

### Error Handling Strategy

**File Not Found**:
```python
if not filepath.exists():
    print(f"Warning: {filename} not found, skipping...")
    continue  # Don't fail, process remaining files
```

**XML Parsing Errors**:
```python
try:
    sheet_root = ET.fromstring(sheet_xml)
except Exception as e:
    print(f"Error processing {excel_file}: {e}")
    return []  # Return empty list, don't crash
```

**No Data Found**:
```python
if not all_breakdowns:
    print("Warning: No breakdowns found in any file!")
    sys.exit(1)  # Exit with error code
```

### Command-Line Interface

**Argument Parsing**:
- Supports both positional and named arguments
- `--week=31` or `--week 31` or just `31`
- Validates week number is provided
- Clear error messages for missing arguments

**Exit Codes**:
- `0`: Success
- `1`: Error (missing week, no data found, file errors)

### Directory Structure Assumptions

```
Weekly Reports/
└── Week N/
    ├── N3 Utility Performance/
    │   ├── Breakdwon report - Utility Section 26-01-2026.xlsx
    │   ├── Breakdwon report - Utility Section 27-01-2026.xlsx
    │   ├── Breakdwon report - Utility Section 28-01-2026.xlsx
    │   ├── Breakdwon report - Utility Section 29-01-2026.xlsx
    │   └── Breakdwon report - Utility Section 30-01-2026.xlsx
    ├── Utility_Section_All_Breakdowns_WeekN.csv  (OUTPUT)
    └── Utility_Section_Current_Status_WeekN.csv   (OUTPUT)
```

### Comparison with extract-utility-vehicles Skill

| Feature | extract-utility-vehicles | extract-utility-breakdowns |
|---------|-------------------------|----------------------------|
| **Purpose** | Daily availability tracking | Breakdown details |
| **Output** | Availability ratios (X/Y) | Breakdown descriptions |
| **Aggregation** | By Area/Owner | Individual units |
| **Time Range** | Weekly summary | Individual days |
| **Target Slide** | Slide 14 | Slides 15 & 16 |
| **Record Count** | ~30 rows (areas) | ~40-50 rows (units) |
| **Key Metric** | Weekly Avg % | TMM No. + Remarks |

Both skills process the same source Excel files but extract different data for different reporting purposes.
