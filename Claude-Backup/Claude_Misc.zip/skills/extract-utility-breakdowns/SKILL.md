---
name: extract-utility-breakdowns
description: Extract utility vehicle breakdown details from N3 daily Excel reports, generating comprehensive weekly breakdown summaries and current status reports for weekly report slides 15 and 16.
---

# Extract Utility Vehicle Breakdowns

## When to Use This Skill

Use this skill when you need to extract detailed breakdown information from N3 Utility Performance daily Excel reports. The skill automatically:
- Extracts breakdown data from all 5 daily Excel files (Monday-Friday)
- Identifies "Not Available" units with TMM numbers, models, and breakdown descriptions
- Generates two CSV outputs:
  - **All Breakdowns**: Complete week's unavailable units (for Slide 15)
  - **Current Status**: Friday-only breakdowns showing ongoing issues (for Slide 16)

This skill complements the `extract-utility-vehicles` skill, which generates daily availability tracking data for Slide 14.

## Usage

### Using Claude Code Slash Command

```bash
/extract-utility-breakdowns 31
/extract-utility-breakdowns --week=31
```

### Using Command Line

```bash
cd "C:\Users\10064957\.claude\skills\extract-utility-breakdowns"
python extract_utility_breakdowns.py --week=31
python extract_utility_breakdowns.py 31
```

### Arguments

- `--week=N` or `--week N` or positional `N`: The week number (required)

## Prerequisites

- Week N folder must exist in Weekly Reports directory
- `Week N/N3 Utility Performance/` subfolder must contain 5 Excel files:
  - `Breakdwon report - Utility Section 26-01-2026.xlsx` (Monday)
  - `Breakdwon report - Utility Section 27-01-2026.xlsx` (Tuesday)
  - `Breakdwon report - Utility Section 28-01-2026.xlsx` (Wednesday)
  - `Breakdwon report - Utility Section 29-01-2026.xlsx` (Thursday)
  - `Breakdwon report - Utility Section 30-01-2026.xlsx` (Friday)
- Note: Filename has "Breakdwon" (typo from source system)

## Data Extraction

The script extracts these fields from each Excel file:

**Excel Columns:**
- Column A: No (row number)
- Column B: Area / Owner (department)
- Column C: Equip model
- Column D: TMM No. (equipment identifier)
- Column E: Description - EOS / Breakdown (Status: "Available" or "Not Available")
- Column F: Remaks /Comment (breakdown details)
- Column G: OEM Assistance Required / Waiting Parts

**Extraction Logic:**
- Only extracts rows where Column E = "Not Available"
- Skips rows without TMM numbers (blank equipment IDs)
- Processes rows starting from Row 3 (Row 2 is header)

## Output Files

### 1. Utility_Section_All_Breakdowns_WeekN.csv (Slide 15)
**Purpose**: Shows ALL unavailable units from Monday-Friday

**Location**: `Week N/Utility_Section_All_Breakdowns_WeekN.csv`

**Columns**:
- `Date`: Day and date (e.g., "Monday 26-01-2026")
- `Area_Owner`: Department responsible for the unit
- `TMM_No`: Equipment identifier (e.g., LD0405, UV0078, BB0002)
- `Model`: Equipment model description
- `Status`: Always "Not Available" (filtered data)
- `Remarks`: Breakdown description and duration
- `OEM_Assistance`: External support needed or parts status

### 2. Utility_Section_Current_Status_WeekN.csv (Slide 16)
**Purpose**: Shows only ongoing breakdowns as of Friday (current status)

**Location**: `Week N/Utility_Section_Current_Status_WeekN.csv`

**Columns**: Same as above, but filtered to Friday data only

## CSV Structure & Content

### Example All Breakdowns Output (Week 31):

```csv
Date,Area_Owner,TMM_No,Model,Status,Remarks,OEM_Assistance
Monday 26-01-2026,Boilermaker,LD0405,Maverick Dble Cab STD Load Bin,Not Available,Engine commision( No comminication between engine and Machine) (SOS - EOS),Requested assistence from OEM.
Monday 26-01-2026,BEV,LD0465,Toyota Hilux DC 2.4 GD6 SR,Not Available,Damaged,Remove from U/G
Tuesday 27-01-2026,Security,LD0595,Toyota Land Cruiser 79 4.2D,Not Available,CWS error (SOS - EOS),
Wednesday 28-01-2026,Logistics,UV0078,FERMEL UV80 (LIBERATOR ON/OFF),Not Available,Replace Axle ( SOS - EOS ),Waiting for spares
```

### Example Current Status Output (Friday only):

```csv
Date,Area_Owner,TMM_No,Model,Status,Remarks,OEM_Assistance
Friday 30-01-2026,Boilermaker,LD0405,Maverick Dble Cab STD Load Bin,Not Available,Engine commision( No comminication between engine and Machine) (SOS - EOS),Requested assistence from OEM.
Friday 30-01-2026,Plant Fitter,LD0452,Maverick Dble Cab STD Load Bin,Not Available,Overheating and powerless (10:45 - EOS),
Friday 30-01-2026,Logistics,UV0078,FERMEL UV80 (LIBERATOR ON/OFF),Not Available,Replace Axle ( SOS - EOS ),Waiting for spares
```

## Equipment Type Prefixes

**Light Duty Vehicles (LD):**
- LD0xxx: Hilux, Land Cruiser, Maverick variants
- Used by: Plant Fitter, Electricians, BEV, Ambulance, Security, etc.

**Utility Vehicles (UV):**
- UV0xxx: Liberator, Fermel variants with cranes/flatdecks
- Used by: Logistics, Hyd Fitter, Boilermaker

**Bobcats (BB):**
- BB0xxx: Small loaders
- Used by: Plant Fitter

## Validation Checks

The skill performs these quality checks:
- All 5 Excel files exist in N3 Utility Performance folder
- Each file has valid sheet structure
- At least one breakdown found per day
- Output CSVs created successfully
- Friday data isolated correctly for current status

## Common Issues & Troubleshooting

**Excel files not found:**
- Ensure `Week N/N3 Utility Performance/` folder exists
- Verify Excel filenames match pattern: `Breakdwon report - Utility Section DD-MM-YYYY.xlsx`
- Note: "Breakdwon" spelling is intentional (source system typo)

**No breakdowns extracted:**
- Check Excel files have data starting from Row 3
- Verify Column E contains "Not Available" status entries
- Ensure Column D (TMM No.) is not blank

**Missing Current Status file:**
- Friday Excel file must be present and named correctly
- Friday file should be dated 30-01-2026 or last day of that week

**Unicode encoding errors:**
- These are cosmetic console display errors
- CSV files are created successfully with UTF-8 encoding
- Verify file existence with `ls -lh` command

## Next Steps After Extraction

1. **Verify Output Files:**
   ```bash
   ls -lh "Week N/Utility_Section"*.csv
   ```

2. **Review Breakdown Counts:**
   - All Breakdowns CSV should have ~40-50 records (varies by week)
   - Current Status CSV should have 5-10 records (Friday only)

3. **Integration into Weekly Report:**
   - Slide 15: Use `Utility_Section_All_Breakdowns_WeekN.csv` for comprehensive breakdown table
   - Slide 16: Use `Utility_Section_Current_Status_WeekN.csv` for current status snapshot

4. **Cross-Reference with Availability Data:**
   - Compare with `Utility_Section_Weekly_Availability_WeekN.csv` (from extract-utility-vehicles skill)
   - Low availability areas should correlate with high breakdown counts

## Related Skills

- **extract-utility-vehicles**: Generates daily availability tracking ratios (Slide 14)
- Both skills work together to provide complete utility vehicle performance picture

## Example Workflow

```bash
# Step 1: Extract availability tracking data (Slide 14)
/extract-utility-vehicles 31

# Step 2: Extract breakdown details (Slides 15 & 16)
/extract-utility-breakdowns 31

# Result: Three CSV files ready for report generation
# - Utility_Section_Weekly_Availability_Week31.csv (Slide 14)
# - Utility_Section_All_Breakdowns_Week31.csv (Slide 15)
# - Utility_Section_Current_Status_Week31.csv (Slide 16)
```

## Notes

- Extraction processes all 5 days automatically (no need to specify dates)
- Dates in CSV are in format "Day DD-MM-YYYY" for readability
- OEM_Assistance column may be empty if no external support requested
- Remarks field contains breakdown time ranges (e.g., "10:45 - EOS" = 10:45 AM to End of Shift)
