#!/usr/bin/env python3
"""
Extract Utility Vehicle availability data from daily breakdown reports.
Processes 5 daily Excel files and generates weekly availability summary.
"""

import sys
import os
import argparse
import zipfile
import xml.etree.ElementTree as ET
import csv
import glob
from collections import defaultdict

def extract_shared_strings(zip_ref):
    """Extract shared strings from Excel file."""
    try:
        shared_strings_xml = zip_ref.read('xl/sharedStrings.xml')
        root = ET.fromstring(shared_strings_xml)
        ns = {'main': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        
        strings = []
        for si in root.findall('.//main:si', ns):
            t = si.find('.//main:t', ns)
            if t is not None and t.text:
                strings.append(t.text)
            else:
                strings.append('')
        return strings
    except Exception as e:
        print(f"Error extracting shared strings: {e}", file=sys.stderr)
        return []

def extract_sheet_data(zip_ref, strings):
    """Extract data from first sheet."""
    try:
        sheet_xml = zip_ref.read('xl/worksheets/sheet1.xml')
        root = ET.fromstring(sheet_xml)
        ns = {'main': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        
        cells = {}
        for row in root.findall('.//main:row', ns):
            for cell in row.findall('.//main:c', ns):
                cell_ref = cell.get('r')
                cell_type = cell.get('t')
                value_elem = cell.find('.//main:v', ns)
                
                if value_elem is not None and value_elem.text:
                    if cell_type == 's':  # String reference
                        idx = int(value_elem.text)
                        value = strings[idx] if idx < len(strings) else ''
                    else:
                        value = value_elem.text
                    cells[cell_ref] = value
        
        return cells
    except Exception as e:
        print(f"Error extracting sheet data: {e}", file=sys.stderr)
        return {}

def parse_daily_file(file_path):
    """Parse a single daily Excel file and return availability data."""
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            strings = extract_shared_strings(zip_ref)
            cells = extract_sheet_data(zip_ref, strings)
            
            # Extract date from cell F1
            date_str = cells.get('F1', '')
            
            # Parse equipment data starting from row 3
            area_counts = defaultdict(lambda: {'total': 0, 'available': 0})
            
            row_num = 3
            while True:
                # Check if we have data in columns B (Area/Owner) and E (Status)
                area_cell = cells.get(f'B{row_num}', '').strip()
                status_cell = cells.get(f'E{row_num}', '').strip()
                
                if not area_cell:  # End of data
                    break
                
                area_counts[area_cell]['total'] += 1
                if status_cell == 'Available':
                    area_counts[area_cell]['available'] += 1
                
                row_num += 1
            
            return date_str, dict(area_counts)
            
    except Exception as e:
        print(f"Error parsing {file_path}: {e}", file=sys.stderr)
        return None, {}

def calculate_color(available, total):
    """Determine color coding based on availability percentage."""
    if total == 0:
        return 'gray'
    
    pct = (available / total) * 100
    
    if pct == 100:
        return 'green'
    elif pct >= 50:
        return 'yellow'
    else:
        return 'red'

def main():
    parser = argparse.ArgumentParser(
        description='Extract utility vehicle availability data from daily reports'
    )
    parser.add_argument('week', type=int, help='Week number (e.g., 31)')
    
    args = parser.parse_args()
    week = args.week
    
    # Find Week folder
    week_folder = f'Week {week}'
    if not os.path.exists(week_folder):
        print(f"Error: {week_folder} folder not found", file=sys.stderr)
        return 1
    
    utility_folder = os.path.join(week_folder, 'N3 Utility Performance')
    if not os.path.exists(utility_folder):
        print(f"Error: {utility_folder} folder not found", file=sys.stderr)
        return 1
    
    # Find all Excel files (daily reports)
    pattern = os.path.join(utility_folder, 'Breakdwon report - Utility Section *.xlsx')
    files = sorted(glob.glob(pattern))
    
    if len(files) == 0:
        print(f"Error: No breakdown reports found in {utility_folder}", file=sys.stderr)
        return 1
    
    print(f"Found {len(files)} daily report(s)")
    
    # Parse all files
    daily_data = []
    for file_path in files:
        date_str, area_data = parse_daily_file(file_path)
        if area_data:
            daily_data.append({
                'file': os.path.basename(file_path),
                'date': date_str,
                'areas': area_data
            })
            print(f"  Parsed: {os.path.basename(file_path)} ({date_str})")
    
    if len(daily_data) == 0:
        print("Error: No data extracted from files", file=sys.stderr)
        return 1
    
    # Get all unique areas
    all_areas = set()
    for day in daily_data:
        all_areas.update(day['areas'].keys())
    
    all_areas = sorted(all_areas)
    
    # Generate output CSV
    output_file = os.path.join(week_folder, f'Utility_Section_Weekly_Availability_Week{week}.csv')
    
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header row
        header = ['Area_Owner']
        for i, day in enumerate(daily_data, 1):
            header.append(f'Day{i}_Available')
            header.append(f'Day{i}_Total')
            header.append(f'Day{i}_Color')
        header.extend(['Weekly_Avg_Pct', 'Total_Available', 'Total_Possible'])
        writer.writerow(header)
        
        # Data rows
        for area in all_areas:
            row = [area]
            
            total_available = 0
            total_possible = 0
            
            for day in daily_data:
                area_data = day['areas'].get(area, {'total': 0, 'available': 0})
                available = area_data['available']
                total = area_data['total']
                color = calculate_color(available, total)
                
                row.extend([available, total, color])
                
                total_available += available
                total_possible += total
            
            # Calculate weekly average
            weekly_avg = (total_available / total_possible * 100) if total_possible > 0 else 0
            
            row.extend([f'{weekly_avg:.1f}', total_available, total_possible])
            writer.writerow(row)
    
    print(f"\nSUCCESS: Generated: {output_file}")
    print(f"  Areas tracked: {len(all_areas)}")
    print(f"  Days processed: {len(daily_data)}")
    
    return 0

if __name__ == '__main__':
    sys.exit(main())
