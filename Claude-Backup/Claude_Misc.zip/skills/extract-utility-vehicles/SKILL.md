---
name: extract-utility-vehicles
description: Extracts daily utility vehicle availability data from N3 Utility Performance breakdown reports and generates weekly availability summary with daily tracking ratios and color coding.
---

# Extract Utility Vehicles

## When to Use This Skill

Use this skill when you need to process utility vehicle breakdown reports for weekly report generation. It reads 5 daily Excel files from the `Week N/N3 Utility Performance/` folder and generates a weekly availability summary showing:

- Daily available/total ratios per Area/Owner (Mon-Fri)
- Color coding for each day (green/yellow/red)
- Weekly average availability percentage
- Total available units across the week

## Usage

```bash
# From Weekly Reports directory
/extract-utility-vehicles 31

# Or directly with Python
python ~/.claude/skills/extract-utility-vehicles/extract_utility_vehicles.py 31
```

**Arguments:**
- `week` (required): Week number to process (e.g., 31)

## Prerequisites

1. **Week folder exists**: `Week N/` directory must exist
2. **Utility Performance folder**: `Week N/N3 Utility Performance/` subdirectory present
3. **Daily breakdown reports**: Excel files named `Breakdwon report - Utility Section DD-02-2026.xlsx`
   - Typically 5 files (Mon-Fri)
   - Note: filename has "Breakdwon" (typo from source system)

## Data Extraction

The script processes each daily Excel file and extracts:

### From Each File:
- **Row 1, Column F**: Date and shift header
- **Row 2**: Column headers (ignored)
- **Rows 3+**: Equipment data
  - **Column B**: Area/Owner (department)
  - **Column E**: Status ("Available" or "Not Available")

### Aggregation Logic:
For each Area/Owner:
1. Count total units (all rows with that area)
2. Count available units (rows where Status = "Available")
3. Calculate daily ratio: Available/Total
4. Apply color coding:
   - 🟢 **Green**: 100% available
   - 🟡 **Yellow**: 50-99% available
   - 🔴 **Red**: 0-49% available

### Weekly Average:
```
Weekly Avg % = (Total Available Unit-Days) / (Total Possible Unit-Days) × 100
```

**Example:**
```
Plant Fitter (5 units):
Mon: 1/5 + Tue: 5/5 + Wed: 5/5 + Thu: 3/5 + Fri: 2/5
= (1+5+5+3+2) / (5×5) = 16/25 = 64%
```

## Output Files

### CSV Structure

**Filename**: `Week N/Utility_Section_Weekly_Availability_WeekN.csv`

**Columns:**
```
Area_Owner,Day1_Available,Day1_Total,Day1_Color,Day2_Available,Day2_Total,Day2_Color,...,Weekly_Avg_Pct,Total_Available,Total_Possible
```

**Example Output:**
```csv
Area_Owner,Day1_Available,Day1_Total,Day1_Color,Day2_Available,Day2_Total,Day2_Color,Day3_Available,Day3_Total,Day3_Color,Day4_Available,Day4_Total,Day4_Color,Day5_Available,Day5_Total,Day5_Color,Weekly_Avg_Pct,Total_Available,Total_Possible
Plant Fitter,4,5,yellow,5,5,green,5,5,green,3,5,yellow,2,5,red,76.0,19,25
Electricians,3,5,yellow,3,5,yellow,4,5,yellow,3,5,yellow,3,5,yellow,64.0,16,25
BEV,1,2,yellow,2,2,green,2,2,green,2,2,green,2,2,green,90.0,9,10
```

## Common Issues & Troubleshooting

### File Not Found
**Error**: `No breakdown reports found`
**Solution**: Verify files exist in `Week N/N3 Utility Performance/` and match naming pattern

### No Data Extracted
**Error**: `No data extracted from files`
**Cause**: Excel file structure changed or corrupted
**Solution**: Manually inspect Excel file; verify Row 2 has headers and Row 3+ has data

### Area/Owner Missing
**Symptom**: Some departments don't appear in output
**Cause**: Department had 0 units all week (not present in any daily file)
**Solution**: This is expected behavior; only areas with units are tracked

## Next Steps After Extraction

1. **Verify CSV output**: Check that all expected areas are present
2. **Generate slide**: Use CSV data to populate Slide 14 (Utility Section Performance Overview)
3. **Create detail slides**: Generate Slides 15-16 for unavailability details

## Example Workflow

```bash
# Step 1: Extract weekly data
/extract-utility-vehicles 31

# Step 2: Review output
cat "Week 31/Utility_Section_Weekly_Availability_Week31.csv"

# Step 3: Verify area count
# Should see: Plant Fitter, Electricians, BEV, Boilermaker, Mechanics, etc.
```

## Technical Notes

- Uses zipfile to read Excel files as XML archives
- Processes `xl/sharedStrings.xml` for text values
- Reads `xl/worksheets/sheet1.xml` for cell data
- Handles missing areas gracefully (0 units tracked)
- Color coding matches slide visual requirements
