# Visual Circuit Builder for NgSpice Simulator

## Overview

Add a drag-and-drop visual circuit schematic editor with bi-directional sync to the existing NgSpice Circuit Simulator. Users can toggle between text netlist editing and visual circuit building.

## User Requirements (Confirmed)

- **Dual Mode**: Toggle between visual builder and text editor with bi-directional sync
- **Advanced Components**: Support R, C, L, diodes, transistors, op-amps, ICs, custom models
- **Library**: Use established schematic library (JointJS recommended)
- **MVP Features**: Drag-drop placement, wire drawing, property editing, save/load

## Architecture Decision: JointJS

**Selected Library**: JointJS (Open Source Edition)

**Rationale**:
- Purpose-built for interactive diagrams with connection ports
- Native port/link system maps perfectly to SPICE nodes
- Built on Backbone.js + SVG (mature, well-documented)
- MIT license, ~200KB bundle size
- Active maintenance and extensive examples

## Implementation Approach

### 1. Layout Changes

**Current**: 2-column grid (Netlist Editor | Results)
**New**: 3-column grid (Netlist Editor | Visual Builder | Results)

```css
.grid {
    grid-template-columns: 0.9fr 1.5fr 1.2fr;  /* Was: 1fr 1.2fr */
}
```

**Visual Builder Panel**:
- JointJS canvas (800x600 viewport with zoom/pan)
- Component palette (draggable R, C, L, V, I, D, Q, M, OPAMP, GND)
- Property editor (modal popup on double-click)
- Mode toggle button ("Text Mode" ↔ "Visual Mode")

### 2. Component Library Design

**Data Structure**:
```javascript
class CircuitComponent {
    id: string           // "R1", "C2"
    type: string         // 'R', 'C', 'L', 'V', 'D', 'Q', 'M', 'OPAMP', 'GND'
    nodes: string[]      // ['n1', 'n2'] - SPICE node connections
    properties: object   // {value: 1000, power_rating: 0.25}
    position: {x, y}     // Canvas coordinates
    rotation: number     // 0, 90, 180, 270
}
```

**Component Schemas**: Define for each type:
- Properties with units, defaults, validation
- SPICE format generator function
- JointJS custom shape definition
- Port configuration (number and positions)

**Supported Components**:
- Passives: R, C, L
- Sources: V (DC/AC/SIN), I
- Semiconductors: D (diode), Q (BJT), M (MOSFET)
- Active: OPAMP (as VCVS E-source)
- Special: GND (ground reference)

### 3. Critical: Netlister Engine

**3.1 Visual → SPICE Netlister**

```javascript
class VisualToSPICENetlister {
    generate(graph) {
        1. Extract components and wires from JointJS graph
        2. Build node connectivity map from wire links
        3. Assign node names:
           - Ground ports → node "0"
           - Connected ports → shared node name (n1, n2, ...)
           - Isolated ports → unique nodes
        4. Validate circuit (check floating nodes, missing ground)
        5. Generate SPICE lines using component schemas
        6. Collect .model statements for semiconductors
        7. Append analysis directives (.ac, .tran, .dc)
        8. Return complete netlist string
    }
}
```

**Node Naming Strategy**:
- Auto-generate sequential node names: n1, n2, n3...
- Ground always = "0"
- Wires group connected ports into same node
- Maintain port-to-node map for editing

**3.2 SPICE → Visual Parser**

```javascript
class SPICEToVisualParser {
    parse(netlist) {
        1. Parse each netlist line using regex patterns
        2. Create CircuitComponent objects with properties
        3. Build node-to-component connectivity map
        4. Apply layout algorithm (force-directed or grid)
        5. Create JointJS elements at calculated positions
        6. Create JointJS links between connected ports
        7. Return cells array for graph.addCells()
    }
}
```

**Parsing Patterns**:
- `R1 in out 1k` → Resistor, nodes=[in, out], value=1000
- `V1 n1 0 DC 5 AC 1` → Voltage source with DC and AC components
- `D1 anode cathode 1N4148` → Diode with model reference
- `.model 1N4148 D(...)` → Extract and store model definitions

**Layout Algorithm**: Simple grid placement initially (can enhance with force-directed)

### 4. UI Implementation

**Mode Toggle**:
```javascript
currentMode = 'text' | 'visual'

toggleMode() {
    if (switching to visual) {
        - Parse netlist → populate canvas
        - Show builder panel, hide textarea
    } else {
        - Generate netlist from canvas
        - Show textarea, hide builder panel
    }
}
```

**Component Palette**:
- Draggable items with SVG icons
- Drop onto canvas creates component at position
- HTML5 drag-and-drop API

**Property Editor**:
- Double-click component → show modal
- Form fields based on component schema
- Save updates component properties
- Trigger sync if enabled

**Wire Drawing**:
- Click source port → drag → click target port
- JointJS handles visual routing (Manhattan style)
- Auto-creates link in graph

### 5. Bi-Directional Sync Strategy

**Sync Triggers**:
- **Manual (Recommended)**: Click "Sync" button or auto-sync on mode toggle
- **On-Change (Optional)**: Debounced 500ms after graph changes

**Sync Direction Rules**:
- Active mode is source of truth
- Text Mode → Canvas is read-only
- Visual Mode → Textarea is read-only (but updated on sync)

**Conflict Resolution**: None needed - single source of truth based on active mode

**Sync Indicator**:
- Badge shows "Synced" (green) or "Out of Sync" (yellow)
- Visual warning before mode switch if unsaved changes

### 6. Data Persistence

**Save Format** (JSON):
```json
{
    "name": "My Circuit",
    "version": "1.0",
    "spice_netlist": "* RC Filter\nV1...",
    "visual_layout": {
        "components": [...],
        "wires": [...]
    },
    "analysis_settings": {"type": "ac"}
}
```

**Storage**:
- Primary: localStorage (auto-save every 30s)
- Secondary: File download/upload (.ngsim format)
- Circuit list dropdown for quick loading

**Template Integration**:
- Extend existing templates with visual layouts
- Pre-positioned components for quick start

### 7. Integration with Existing Features

**Live Mode**:
- Extract parameters from canvas components (same as textarea parsing)
- Slider changes update component.properties.value
- Visual feedback: flash component on change
- Works identically in both Text and Visual modes

**Animation**:
- Generate SVG paths from JointJS wire links
- Clone canvas SVG for animation overlay
- Parse simulation currents: `i(V1) = 0.001`
- Animate dots along actual circuit topology
- Use real current values from simulation results

**Simulation Flow**:
- No backend changes needed
- Visual mode generates netlist string → POST /api/simulate
- Same parse_ngspice_output() and plotResults() functions
- Transparent to simulation engine

## File Structure

### New Files (to be created as separate .js files, then embedded in HTML_TEMPLATE)

1. **component_library.js** (~400 lines)
   - COMPONENT_SCHEMAS definitions
   - JointJS custom shapes (joint.shapes.circuit.*)
   - Symbol SVG paths

2. **circuit_builder.js** (~500 lines)
   - VisualToSPICENetlister class
   - SPICEToVisualParser class
   - Value parsing utilities

3. **builder_ui.js** (~300 lines)
   - Mode toggle logic
   - Palette drag-and-drop
   - Property editor
   - Sync strategy

4. **circuit_storage.js** (~200 lines)
   - Save/load to localStorage
   - File download/upload
   - Template management

### Modified Files

**circuit_sim_standalone.py** - HTML_TEMPLATE section:

**Add CSS** (~150 lines):
- `.visual-builder` panel styling
- `#componentPalette` drag sources
- `#propertyEditor` modal
- `.joint-paper` canvas styling
- Responsive grid updates

**Add HTML** (~100 lines):
- Visual builder container with JointJS canvas
- Component palette div
- Property editor modal
- Mode toggle button
- Circuit save/load controls

**Add JavaScript** (~50 lines for integration):
- Script tags for JointJS + dependencies
- Initialize graph and paper on page load
- Wire up mode toggle and sync handlers

**Dependencies to Add**:
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.21/lodash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/backbone.js/1.4.1/backbone-min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jointjs@3.7.0/dist/joint.min.js"></script>
```

## Implementation Phases

### Phase 1: MVP (Week 1)
- JointJS integration
- Basic components (R, C, L, V, GND)
- Drag-and-drop from palette
- Wire drawing (click port to port)
- Visual → SPICE netlister (simple circuits)
- Mode toggle
- Property editor for values
- Manual sync button

**Test**: Create RC filter visually → Generate netlist → Run simulation → Verify plot

### Phase 2: Full Library (Week 2)
- All component types (D, Q, M, OPAMP, I)
- Advanced source properties (SIN, PULSE)
- SPICE → Visual parser (reverse direction)
- Auto-layout algorithm
- Save/load localStorage
- Template visual layouts

**Test**: Load BJT amplifier netlist → Verify visual → Edit → Sync → Verify SPICE accuracy

### Phase 3: Advanced Features (Week 3)
- Live Mode integration (sliders update canvas)
- Animation integration (real currents)
- File download/upload
- Component rotation
- Wire routing options
- Zoom/pan controls

**Test**: Full workflow - Load → Edit → Live Mode → Animate → Save

### Phase 4: Polish (Week 4)
- User guide overlay
- Keyboard shortcuts
- Component search
- Export to image
- Performance optimization
- Error handling
- Accessibility

## Verification Strategy

**Unit Tests**:
- Component schema SPICE formatting
- Netlister node assignment algorithm
- Parser regex patterns
- Value parsing utilities

**Integration Tests**:
- Round-trip: Text → Visual → Text (preserves netlist)
- Simulation equivalence (visual vs text produce same results)
- Sync accuracy (changes propagate correctly)

**Example Circuits**:
1. RC Filter (3 nodes, 4 components)
2. BJT Amplifier (6 nodes, 8 components)
3. Half-Wave Rectifier (4 nodes, 5 components)
4. Op-Amp Circuit (4 nodes, 5 components)
5. Complex multi-source (10 nodes, 15 components)

## Known Limitations

**Not Supported in MVP**:
- Subcircuits (.subckt definitions)
- Behavioral sources (B-sources)
- Transmission lines
- Advanced controlled sources (H, F, G beyond E)
- Custom component symbols (user import)

**Workaround**: Display as "Advanced Component" placeholder with warning

**Performance Limits**:
- JointJS slows beyond ~100 components
- Manual sync recommended for large circuits
- Netlisting >200 components may take >500ms

## Risk Mitigation

**Technical Risks**:
- Netlisting accuracy → Comprehensive test suite, validation against LTspice
- JointJS performance → Implement virtualization, set component limit warning
- Browser compatibility → Test on Chrome, Firefox, Edge, Safari

**UX Risks**:
- Complex UI → In-app tutorial, context-sensitive help tooltips
- Sync confusion → Clear visual indicators, modal warnings
- Feature creep → Strict MVP scope, user feedback gates

## Critical Files to Modify

1. **circuit_sim_standalone.py** - HTML_TEMPLATE (lines 18-833)
   - Add 3-column grid CSS
   - Add visual builder HTML structure
   - Embed new JavaScript modules

2. **component_library.js** (NEW) - Component definitions
3. **circuit_builder.js** (NEW) - Netlisting engine
4. **builder_ui.js** (NEW) - UI interaction logic
5. **circuit_storage.js** (NEW) - Persistence layer

## Success Criteria

✅ User can build simple RC filter visually
✅ Generated netlist simulates correctly
✅ Mode toggle preserves circuit data
✅ Bi-directional sync works accurately
✅ Live Mode and Animation integrate seamlessly
✅ Save/load circuits to localStorage
✅ Mobile responsive (tabbed interface)
✅ No breaking changes to existing features

## Next Steps After Approval

1. Create component_library.js with COMPONENT_SCHEMAS
2. Implement VisualToSPICENetlister core algorithm
3. Create JointJS custom shapes for circuit symbols
4. Add visual builder panel to HTML_TEMPLATE
5. Implement mode toggle and sync logic
6. Test with RC filter example
7. Iterate based on testing results
