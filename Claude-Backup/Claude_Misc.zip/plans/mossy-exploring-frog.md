# Cloud Migration Plan: WhatsApp & Whisper MCP to Google Cloud Platform

## Executive Summary

**Goal:** Migrate WhatsApp MCP and Whisper MCP servers to Google Cloud Platform for 24/7 mobile access from Claude.

**Recommended Solution:** Single Compute Engine e2-micro VM running both services
- **Cost:** $0/month (within GCP always-free tier)
- **Performance:** <2s response time (always warm, no cold starts)
- **Budget Compliance:** Well within $10/month limit ✅

---

## Architecture Overview

```
Claude Mobile App
    ↓ HTTPS
Nginx Reverse Proxy (VM)
    ├─ /whatsapp/* → WhatsApp MCP Server (port 8081)
    │   ↓
    │   WhatsApp Bridge (Go) (port 8080)
    │   ↓
    │   WhatsApp Web API
    │
    └─ /whisper/* → Whisper MCP Server (port 8082)
        ↓
        OpenAI API
```

**VM Specifications:**
- Machine type: e2-micro (2 vCPU, 1GB RAM)
- Region: us-central1-a (always-free eligible)
- OS: Debian 12
- Disk: 30GB standard persistent disk (free tier)
- Network: Static external IP with HTTPS

---

## Why This Solution

**Requirements Met:**
✅ 24/7 availability for mobile access
✅ <2s response time (no cold starts)
✅ $0/month cost (within always-free tier)
✅ Full cloud migration (no desktop dependency)
✅ WhatsApp session persistence
✅ Secure HTTPS endpoints

**Rejected Alternatives:**
- ❌ Cloud Run: Would need min-instances=1 for <2s performance (~$58/month, exceeds budget)
- ❌ Hybrid (local bridge): Desktop shuts down regularly (not 24/7)
- ❌ Shared hosting: Security concerns with WhatsApp session data

---

## Implementation Steps

### Phase 1: GCP Project Setup (Week 1)

**1.1 Create GCP Project**
```bash
gcloud projects create martha-mcp --name="Martha MCP Services"
gcloud config set project martha-mcp
```

**1.2 Enable Required APIs**
```bash
gcloud services enable compute.googleapis.com
gcloud services enable storage.googleapis.com
gcloud services enable secretmanager.googleapis.com
```

**1.3 Create Cloud Storage Buckets**
```bash
# For audio files (nearline storage for cost optimization)
gsutil mb -c NEARLINE -l us-central1 gs://martha-audio-files

# For WhatsApp database backups
gsutil mb -c STANDARD -l us-central1 gs://whatsapp-mcp-backups
```

**1.4 Store Secrets**
```bash
# Store OpenAI API key
gcloud secrets create openai-api-key \
  --data-file=<(echo -n "sk-proj-mZy7UEiRy_vnxZNzSoOl...")

# Generate and store MCP API key for authentication
openssl rand -hex 32 > mcp-api-key.txt
gcloud secrets create mcp-api-key --data-file=mcp-api-key.txt
```

---

### Phase 2: VM Provisioning (Week 1)

**2.1 Create VM Instance**
```bash
gcloud compute instances create martha-mcp \
  --machine-type=e2-micro \
  --zone=us-central1-a \
  --image-family=debian-12 \
  --image-project=debian-cloud \
  --boot-disk-size=30GB \
  --boot-disk-type=pd-standard \
  --tags=http-server,https-server \
  --scopes=cloud-platform
```

**2.2 Reserve Static IP**
```bash
gcloud compute addresses create martha-mcp-ip \
  --region=us-central1

# Get IP address for DNS configuration
gcloud compute addresses describe martha-mcp-ip \
  --region=us-central1 --format="get(address)"
```

**2.3 Configure Firewall Rules**
```bash
gcloud compute firewall-rules create allow-http \
  --allow=tcp:80 \
  --target-tags=http-server

gcloud compute firewall-rules create allow-https \
  --allow=tcp:443 \
  --target-tags=https-server
```

**2.4 Configure DNS** (Optional but recommended)
- Point domain (e.g., `martha-mcp.yourdomain.com`) to static IP
- Alternative: Use IP directly in Claude config

---

### Phase 3: Software Installation (Week 2)

**3.1 SSH into VM and Install Dependencies**
```bash
gcloud compute ssh martha-mcp --zone=us-central1-a

# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install core dependencies
sudo apt-get install -y \
  python3-pip \
  python3-venv \
  golang-go \
  sqlite3 \
  ffmpeg \
  nginx \
  certbot \
  python3-certbot-nginx \
  git \
  curl

# Install uv package manager
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**3.2 Install gcsfuse for Cloud Storage Mount**
```bash
export GCSFUSE_REPO=gcsfuse-`lsb_release -c -s`
echo "deb https://packages.cloud.google.com/apt $GCSFUSE_REPO main" | \
  sudo tee /etc/apt/sources.list.d/gcsfuse.list
curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | \
  sudo apt-key add -
sudo apt-get update
sudo apt-get install -y gcsfuse
```

---

### Phase 4: WhatsApp Bridge Migration (Week 2)

**4.1 Build Go Bridge for Linux**

On Windows development machine:
```bash
cd C:\whatsapp-mcp\whatsapp-bridge

# Cross-compile for Linux
$env:GOOS="linux"
$env:GOARCH="amd64"
$env:CGO_ENABLED="1"
go build -o whatsapp-bridge-linux main.go
```

**4.2 Transfer Files to VM**
```bash
# From Windows, copy bridge binary and databases
gcloud compute scp whatsapp-bridge-linux martha-mcp:/tmp/ --zone=us-central1-a
gcloud compute scp store/whatsapp.db martha-mcp:/tmp/ --zone=us-central1-a
gcloud compute scp store/messages.db martha-mcp:/tmp/ --zone=us-central1-a
```

**4.3 Set Up Bridge on VM**
```bash
# On VM
sudo mkdir -p /opt/whatsapp-bridge/store
sudo mv /tmp/whatsapp-bridge-linux /opt/whatsapp-bridge/whatsapp-bridge
sudo mv /tmp/*.db /opt/whatsapp-bridge/store/
sudo chmod +x /opt/whatsapp-bridge/whatsapp-bridge
```

**4.4 Create systemd Service for Bridge**
```bash
sudo tee /etc/systemd/system/whatsapp-bridge.service <<EOF
[Unit]
Description=WhatsApp Bridge Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/whatsapp-bridge
ExecStart=/opt/whatsapp-bridge/whatsapp-bridge
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable whatsapp-bridge.service
sudo systemctl start whatsapp-bridge.service
```

**4.5 Verify Bridge is Running**
```bash
sudo systemctl status whatsapp-bridge
curl http://localhost:8080/api  # Should return bridge status
```

**4.6 Re-authenticate WhatsApp Session**
```bash
# Stop bridge
sudo systemctl stop whatsapp-bridge

# Remove old session database (Windows-tied)
sudo rm /opt/whatsapp-bridge/store/whatsapp.db

# Start bridge and monitor logs for QR code
sudo systemctl start whatsapp-bridge
sudo journalctl -u whatsapp-bridge -f

# Scan QR code displayed in logs with your phone
# Once "Connected" appears in logs, session is established
```

---

### Phase 5: WhatsApp MCP Server Setup (Week 2)

**5.1 Clone MCP Server Code to VM**
```bash
# On VM
sudo mkdir -p /opt/whatsapp-mcp
cd /opt/whatsapp-mcp

# Copy files from Windows or clone from repo
# For now, manual transfer:
```

On Windows:
```bash
gcloud compute scp --recurse C:\whatsapp-mcp\whatsapp-mcp-server\ martha-mcp:/tmp/whatsapp-mcp-server --zone=us-central1-a
```

On VM:
```bash
sudo mv /tmp/whatsapp-mcp-server/* /opt/whatsapp-mcp/
cd /opt/whatsapp-mcp
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

**5.2 Modify MCP Server for HTTP Transport**

**Critical File:** `/opt/whatsapp-mcp/main.py`

Add HTTP transport support:
```python
# Add at top of file
from fastmcp import FastMCP
from fastmcp.transports import create_http_transport
import uvicorn

# Replace if __name__ == "__main__" block with:
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--transport", default="stdio", choices=["stdio", "http"])
    parser.add_argument("--port", type=int, default=8081)
    args = parser.parse_args()

    if args.transport == "http":
        transport = create_http_transport(port=args.port)
        mcp.run(transport=transport)
    else:
        mcp.run()  # Default stdio
```

**5.3 Create systemd Service for WhatsApp MCP**
```bash
sudo tee /etc/systemd/system/whatsapp-mcp.service <<EOF
[Unit]
Description=WhatsApp MCP Server
After=whatsapp-bridge.service
Requires=whatsapp-bridge.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/whatsapp-mcp
Environment="PATH=/opt/whatsapp-mcp/.venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=/opt/whatsapp-mcp/.venv/bin/python main.py --transport http --port 8081
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable whatsapp-mcp.service
sudo systemctl start whatsapp-mcp.service
```

**5.4 Test WhatsApp MCP Endpoint**
```bash
curl http://localhost:8081/health
```

---

### Phase 6: Whisper MCP Server Setup (Week 2)

**6.1 Sync Audio Files to Cloud Storage**

On Windows:
```bash
gsutil -m rsync -r "C:\Users\10064957\My Drive\GDVault\MarthaVault\media\audio" gs://martha-audio-files/
```

**6.2 Mount Cloud Storage on VM**
```bash
# On VM
sudo mkdir -p /mnt/audio
sudo gcsfuse martha-audio-files /mnt/audio

# Add to /etc/fstab for auto-mount on reboot
echo "martha-audio-files /mnt/audio gcsfuse rw,allow_other,file_mode=777,dir_mode=777" | sudo tee -a /etc/fstab
```

**6.3 Transfer Whisper MCP Code**

On Windows:
```bash
gcloud compute scp --recurse "C:\Users\10064957\.claude\mcp-servers\mcp-server-whisper" martha-mcp:/tmp/ --zone=us-central1-a
```

On VM:
```bash
sudo mkdir -p /opt/whisper-mcp
sudo mv /tmp/mcp-server-whisper/* /opt/whisper-mcp/
cd /opt/whisper-mcp
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

**6.4 Retrieve OpenAI API Key from Secret Manager**
```bash
# On VM
gcloud secrets versions access latest --secret=openai-api-key > /tmp/openai-key
```

**6.5 Modify Whisper MCP for HTTP Transport**

**Critical File:** `/opt/whisper-mcp/src/mcp_server_whisper/server.py`

Add HTTP transport option (similar pattern to WhatsApp MCP).

**6.6 Create systemd Service for Whisper MCP**
```bash
sudo tee /etc/systemd/system/whisper-mcp.service <<EOF
[Unit]
Description=Whisper MCP Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/whisper-mcp
Environment="PATH=/opt/whisper-mcp/.venv/bin:/usr/local/bin:/usr/bin:/bin"
Environment="OPENAI_API_KEY=$(cat /tmp/openai-key)"
Environment="AUDIO_FILES_PATH=/mnt/audio"
ExecStart=/opt/whisper-mcp/.venv/bin/python -m mcp_server_whisper.server --transport http --port 8082
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable whisper-mcp.service
sudo systemctl start whisper-mcp.service
```

**6.7 Test Whisper MCP Endpoint**
```bash
curl http://localhost:8082/health
```

---

### Phase 7: Nginx Reverse Proxy & SSL (Week 3)

**7.1 Configure Nginx**
```bash
sudo tee /etc/nginx/sites-available/martha-mcp <<'EOF'
# Rate limiting
limit_req_zone $binary_remote_addr zone=mcp_limit:10m rate=10r/s;

upstream whatsapp_mcp {
    server localhost:8081;
}

upstream whisper_mcp {
    server localhost:8082;
}

server {
    listen 80;
    server_name martha-mcp.example.com;  # Replace with your domain or IP

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$server_name$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name martha-mcp.example.com;  # Replace with your domain or IP

    # SSL will be configured by certbot

    # API key authentication
    set $api_key "";
    if ($http_authorization ~* "Bearer (.+)") {
        set $api_key $1;
    }

    # Load expected API key from file
    set $expected_key "PLACEHOLDER";  # Will be replaced with actual key

    # Reject unauthorized requests
    if ($api_key != $expected_key) {
        return 401;
    }

    location /whatsapp/ {
        limit_req zone=mcp_limit burst=20;

        proxy_pass http://whatsapp_mcp/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_read_timeout 300s;
        proxy_connect_timeout 10s;
    }

    location /whisper/ {
        limit_req zone=mcp_limit burst=5;

        proxy_pass http://whisper_mcp/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_read_timeout 600s;
        proxy_connect_timeout 10s;
    }

    location /health {
        access_log off;
        return 200 "OK\n";
        add_header Content-Type text/plain;
    }
}
EOF

# Replace PLACEHOLDER with actual API key
API_KEY=$(gcloud secrets versions access latest --secret=mcp-api-key)
sudo sed -i "s/PLACEHOLDER/$API_KEY/" /etc/nginx/sites-available/martha-mcp

# Enable site
sudo ln -s /etc/nginx/sites-available/martha-mcp /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default  # Remove default site
sudo nginx -t  # Test configuration
sudo systemctl reload nginx
```

**7.2 Obtain SSL Certificate**
```bash
# If using domain name
sudo certbot --nginx -d martha-mcp.example.com

# If using IP only (self-signed)
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/nginx-selfsigned.key \
  -out /etc/ssl/certs/nginx-selfsigned.crt \
  -subj "/CN=$(gcloud compute addresses describe martha-mcp-ip --region=us-central1 --format='get(address)')"

# Update nginx config to use self-signed cert
sudo tee -a /etc/nginx/sites-available/martha-mcp <<EOF
    ssl_certificate /etc/ssl/certs/nginx-selfsigned.crt;
    ssl_certificate_key /etc/ssl/private/nginx-selfsigned.key;
EOF

sudo systemctl reload nginx
```

---

### Phase 8: Claude Mobile Configuration (Week 3)

**8.1 Get Connection Details**
```bash
# On VM
STATIC_IP=$(gcloud compute addresses describe martha-mcp-ip --region=us-central1 --format='get(address)')
API_KEY=$(gcloud secrets versions access latest --secret=mcp-api-key)

echo "MCP Server URL: https://$STATIC_IP"
echo "API Key: $API_KEY"
```

**8.2 Update Claude Mobile MCP Config**

In Claude mobile app settings or config file:
```json
{
  "mcpServers": {
    "whatsapp": {
      "url": "https://YOUR_STATIC_IP/whatsapp",
      "transport": "http",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    },
    "whisper": {
      "url": "https://YOUR_STATIC_IP/whisper",
      "transport": "http",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

**8.3 Test from Mobile**
- Open Claude mobile app
- Try WhatsApp tool: `/whatsapp list_chats`
- Try Whisper tool: `/whisper list_audio_files`
- Verify <2s response time

---

### Phase 9: Monitoring & Backups (Week 3)

**9.1 Set Up Automated Database Backups**
```bash
# On VM
sudo tee /usr/local/bin/backup-whatsapp-db.sh <<'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
cp /opt/whatsapp-bridge/store/whatsapp.db /tmp/whatsapp_$DATE.db
cp /opt/whatsapp-bridge/store/messages.db /tmp/messages_$DATE.db
gsutil cp /tmp/whatsapp_$DATE.db gs://whatsapp-mcp-backups/
gsutil cp /tmp/messages_$DATE.db gs://whatsapp-mcp-backups/
rm /tmp/whatsapp_$DATE.db /tmp/messages_$DATE.db
EOF

sudo chmod +x /usr/local/bin/backup-whatsapp-db.sh

# Schedule every 6 hours
(crontab -l 2>/dev/null; echo "0 */6 * * * /usr/local/bin/backup-whatsapp-db.sh") | crontab -
```

**9.2 Configure Cloud Monitoring**
```bash
# Create uptime check for WhatsApp endpoint
gcloud monitoring uptime-checks create whatsapp-mcp-health \
  --resource-type=uptime-url \
  --host=$STATIC_IP \
  --path=/whatsapp/health \
  --port=443 \
  --protocol=HTTPS \
  --check-interval=60s

# Create uptime check for Whisper endpoint
gcloud monitoring uptime-checks create whisper-mcp-health \
  --resource-type=uptime-url \
  --host=$STATIC_IP \
  --path=/whisper/health \
  --port=443 \
  --protocol=HTTPS \
  --check-interval=60s
```

**9.3 Set Up Log Monitoring**
```bash
# On VM - monitor service health
sudo tee /usr/local/bin/check-services.sh <<'EOF'
#!/bin/bash
services=("whatsapp-bridge" "whatsapp-mcp" "whisper-mcp" "nginx")
for service in "${services[@]}"; do
  if ! systemctl is-active --quiet $service; then
    echo "ALERT: $service is down!" | logger -t service-monitor
    systemctl restart $service
  fi
done
EOF

sudo chmod +x /usr/local/bin/check-services.sh

# Run every 5 minutes
(crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/check-services.sh") | crontab -
```

---

### Phase 10: Audio Sync Automation (Week 3)

**10.1 Set Up Bidirectional Sync on Windows Desktop**

Create PowerShell script: `C:\Scripts\sync-audio-to-cloud.ps1`
```powershell
# Sync local audio to cloud
gsutil -m rsync -r "C:\Users\10064957\My Drive\GDVault\MarthaVault\media\audio" gs://martha-audio-files/

# Sync cloud audio back to local (for TTS-generated files)
gsutil -m rsync -r gs://martha-audio-files/ "C:\Users\10064957\My Drive\GDVault\MarthaVault\media\audio"
```

**10.2 Schedule Hourly Sync (Windows Task Scheduler)**
```powershell
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-File C:\Scripts\sync-audio-to-cloud.ps1"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Hours 1)
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERNAME" -LogonType Interactive
Register-ScheduledTask -TaskName "SyncAudioToCloud" -Action $action -Trigger $trigger -Principal $principal
```

---

## Critical Files Modified

### Files Requiring HTTP Transport Modification

1. **`/opt/whatsapp-mcp/main.py`**
   - Add argparse for `--transport` and `--port` flags
   - Add conditional HTTP transport initialization
   - Location on Windows: `C:\whatsapp-mcp\whatsapp-mcp-server\main.py`

2. **`/opt/whisper-mcp/src/mcp_server_whisper/server.py`**
   - Add HTTP transport support
   - Add CLI argument parsing
   - Location on Windows: `C:\Users\10064957\.claude\mcp-servers\mcp-server-whisper\src\mcp_server_whisper\server.py`

### Configuration Files Created

3. **`/etc/systemd/system/whatsapp-bridge.service`** - Bridge systemd service
4. **`/etc/systemd/system/whatsapp-mcp.service`** - WhatsApp MCP systemd service
5. **`/etc/systemd/system/whisper-mcp.service`** - Whisper MCP systemd service
6. **`/etc/nginx/sites-available/martha-mcp`** - Nginx reverse proxy config
7. **`/usr/local/bin/backup-whatsapp-db.sh`** - Database backup script
8. **`/usr/local/bin/check-services.sh`** - Service health monitoring script

---

## Verification Steps

### Test WhatsApp MCP

```bash
# On VM
curl -H "Authorization: Bearer $(gcloud secrets versions access latest --secret=mcp-api-key)" \
  https://localhost/whatsapp/health

# From mobile (after configuration)
# In Claude app:
"List my recent WhatsApp chats"
# Should invoke mcp__whatsapp__list_chats and return results in <2s
```

### Test Whisper MCP

```bash
# On VM
curl -H "Authorization: Bearer $(gcloud secrets versions access latest --secret=mcp-api-key)" \
  https://localhost/whisper/health

# From mobile (after configuration)
# In Claude app:
"List audio files in my vault"
# Should invoke mcp__whisper__list_audio_files and return results in <2s
```

### Test WhatsApp Session Persistence

```bash
# On VM
sudo systemctl restart whatsapp-bridge
sleep 30
sudo journalctl -u whatsapp-bridge --since "1 minute ago"
# Should show "Connected" without QR code request
# If QR code appears, session was lost - need to re-authenticate
```

### Test Full Mobile Workflow

1. **Send WhatsApp message from mobile:**
   - Ask Claude: "Send a WhatsApp message to Amelia Padi asking about delivery status"
   - Verify message sent successfully
   - Response time should be <2s

2. **Transcribe audio from mobile:**
   - Ask Claude: "Transcribe the latest audio file"
   - Verify transcription completes
   - Response time should be <5s (depends on file size + OpenAI API)

---

## Cost Monitoring

### Monthly Free Tier Limits

- **Compute Engine e2-micro**: 1 instance, 720 hours/month (us-central1) ✅
- **Standard Persistent Disk**: 30GB HDD ✅
- **Network Egress**: 1GB/month to most regions ⚠️ (monitor usage)
- **Cloud Storage**: 5GB standard storage ✅
- **Operations**: 5,000 Class A, 50,000 Class B operations/month ✅

### Set Up Budget Alert
```bash
gcloud billing budgets create \
  --billing-account=YOUR_BILLING_ACCOUNT_ID \
  --display-name="MCP Monthly Budget" \
  --budget-amount=10 \
  --threshold-rule=percent=50 \
  --threshold-rule=percent=90 \
  --threshold-rule=percent=100
```

---

## Troubleshooting Guide

### WhatsApp Session Lost

**Symptoms:** Tools return "Not connected" errors

**Solution:**
```bash
# SSH into VM
gcloud compute ssh martha-mcp --zone=us-central1-a

# Stop services
sudo systemctl stop whatsapp-mcp whatsapp-bridge

# Remove session database
sudo rm /opt/whatsapp-bridge/store/whatsapp.db

# Start bridge and watch for QR code
sudo systemctl start whatsapp-bridge
sudo journalctl -u whatsapp-bridge -f

# Scan QR code with phone
# Once connected, restart MCP
sudo systemctl start whatsapp-mcp
```

### Service Not Responding

**Symptoms:** 502 Bad Gateway or connection timeout

**Solution:**
```bash
# Check service status
sudo systemctl status whatsapp-bridge whatsapp-mcp whisper-mcp nginx

# Check logs
sudo journalctl -u whatsapp-bridge -n 50
sudo journalctl -u whatsapp-mcp -n 50
sudo journalctl -u whisper-mcp -n 50
sudo tail -f /var/log/nginx/error.log

# Restart all services
sudo systemctl restart whatsapp-bridge whatsapp-mcp whisper-mcp nginx
```

### Disk Space Full

**Symptoms:** Services crash, database corruption

**Solution:**
```bash
# Check disk usage
df -h

# Find large files
du -sh /opt/* /var/* 2>/dev/null | sort -h

# Clean up old backups in Cloud Storage
gsutil ls gs://whatsapp-mcp-backups/ | head -n -10 | xargs gsutil rm

# Clear nginx logs
sudo truncate -s 0 /var/log/nginx/*.log
```

---

## Timeline

- **Week 1:** GCP setup, VM provisioning (5-8 hours)
- **Week 2:** Software installation, service migration (10-15 hours)
- **Week 3:** Testing, monitoring setup, cutover (5-8 hours)

**Total Estimated Effort:** 20-30 hours over 3 weeks

---

## Success Criteria

✅ WhatsApp MCP accessible from Claude mobile via HTTPS
✅ Whisper MCP accessible from Claude mobile via HTTPS
✅ Response time <2 seconds for all operations
✅ WhatsApp session persists across VM restarts
✅ Monthly cost: $0 (within always-free tier)
✅ 99.9% uptime (excluding planned maintenance)
✅ Audio files synced bidirectionally between desktop and cloud
✅ Automated backups every 6 hours
✅ Service health monitoring active
