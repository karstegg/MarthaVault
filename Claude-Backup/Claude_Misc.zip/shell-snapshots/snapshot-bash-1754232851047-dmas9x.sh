# Snapshot file
# Unset all aliases to avoid conflicts with functions
unalias -a 2>/dev/null || true
# Functions
eval "$(echo 'cHJvZmlsZV9kICgpIAp7IAogICAgbG9jYWwgZmlsZT07CiAgICBmb3IgZmlsZSBpbiAkKGV4cG9y
dCBMQ19DT0xMQVRFPUM7IGVjaG8gL2V0Yy9wcm9maWxlLmQvKi4kMSk7CiAgICBkbwogICAgICAg
IFsgLWUgIiR7ZmlsZX0iIF0gJiYgLiAiJHtmaWxlfSI7CiAgICBkb25lOwogICAgaWYgWyAtbiAi
JHtNSU5HV19NT1VOVF9QT0lOVH0iIF07IHRoZW4KICAgICAgICBmb3IgZmlsZSBpbiAkKGV4cG9y
dCBMQ19DT0xMQVRFPUM7IGVjaG8gJHtNSU5HV19NT1VOVF9QT0lOVH0vZXRjL3Byb2ZpbGUuZC8q
LiQxKTsKICAgICAgICBkbwogICAgICAgICAgICBbIC1lICIke2ZpbGV9IiBdICYmIC4gIiR7Zmls
ZX0iOwogICAgICAgIGRvbmU7CiAgICBmaQp9Cg==' | base64 -d)" > /dev/null 2>&1
# Shell Options
shopt -u autocd
shopt -u assoc_expand_once
shopt -u cdable_vars
shopt -u cdspell
shopt -u checkhash
shopt -u checkjobs
shopt -s checkwinsize
shopt -s cmdhist
shopt -u compat31
shopt -u compat32
shopt -u compat40
shopt -u compat41
shopt -u compat42
shopt -u compat43
shopt -u compat44
shopt -u completion_strip_exe
shopt -s complete_fullquote
shopt -u direxpand
shopt -u dirspell
shopt -u dotglob
shopt -u execfail
shopt -u expand_aliases
shopt -u extdebug
shopt -u extglob
shopt -s extquote
shopt -u failglob
shopt -s force_fignore
shopt -s globasciiranges
shopt -s globskipdots
shopt -u globstar
shopt -u gnu_errfmt
shopt -u histappend
shopt -u histreedit
shopt -u histverify
shopt -s hostcomplete
shopt -u huponexit
shopt -u inherit_errexit
shopt -s interactive_comments
shopt -u lastpipe
shopt -u lithist
shopt -u localvar_inherit
shopt -u localvar_unset
shopt -s login_shell
shopt -u mailwarn
shopt -u no_empty_cmd_completion
shopt -u nocaseglob
shopt -u nocasematch
shopt -u noexpand_translation
shopt -u nullglob
shopt -s patsub_replacement
shopt -s progcomp
shopt -u progcomp_alias
shopt -s promptvars
shopt -u restricted_shell
shopt -u shift_verbose
shopt -s sourcepath
shopt -u varredir_close
shopt -u xpg_echo
set -o braceexpand
set -o hashall
set -o interactive-comments
set -o monitor
set -o onecmd
shopt -s expand_aliases
# Aliases
alias -- ll='ls -l'
alias -- ls='ls -F --color=auto --show-control-chars'
# Check for rg availability
if ! command -v rg >/dev/null 2>&1; then
  alias rg=''\''C:\Users\10064957\AppData\Roaming\npm\node_modules\@anthropic-ai\claude-code\vendor\ripgrep\x64-win32\rg.exe'\'''
fi
export PATH='/mingw64/bin:/usr/bin:/c/Users/10064957/bin:/c/Spice64/bin:/c/Python313/Scripts:/c/msys64/ucrt64/bin:/c/Python313:/c/Python312/Scripts:/c/Python312:/c/Program Files/Common Files/Oracle/Java/javapath:/c/Python311/Scripts:/c/Python311:/c/Windows/system32:/c/Windows:/c/Windows/System32/Wbem:/c/Windows/System32/WindowsPowerShell/v1.0:/c/Windows/System32/OpenSSH:/c/Program Files/dotnet:/c/ProgramData/chocolatey/bin:/c/Users/10064957/Documents/51. Private/Whisper Minute Taker/ffmpeg-master-latest-win64-gpl/bin:/c/Program Files/Java/jdk-21/bin:/c/texlive/2023/bin/windows:/c/Program Files/GTK3-Runtime Win64/bin:/c/Program Files/GTK3-Runtime Win64/bin:/c/Program Files/Docker/Docker/resources/bin:/c/Program Files/CMake/bin:/c/Program Files/Graphviz/bin:/c/Python311/Lib/site-packages/PySpice/Spice/NgSpice/Spice64_dll/dll-vs:/c/ta-lib/c/lib:/cmd:/c/Program Files/nodejs:/c/Program Files/Go/bin:/c/ffmpeg/bin:/c/Users/10064957/.local/bin:/c/Users/10064957/AppData/Local/Programs/Python/Python37/Scripts:/c/Users/10064957/AppData/Local/Programs/Python/Python37:/c/Users/1006:/c/Program Files/GitHub CLI:/c/Spice64/bin:/c/Users/10064957/.local/bin:/c/Users/10064957/AppData/Local/Programs/Python/Python37/Scripts:/c/Users/10064957/AppData/Local/Programs/Python/Python37:/c/Users/10064957/AppData/Local/miniconda3:/c/Users/10064957/AppData/Local/miniconda3/Library/mingw-w64/bin:/c/Users/10064957/AppData/Local/miniconda3/Library/usr/bin:/c/Users/10064957/AppData/Local/miniconda3/Library/bin:/c/Users/10064957/AppData/Local/miniconda3/Scripts:/c/Users/10064957/AppData/Local/Programs/Python/Python310/Scripts:/c/Users/10064957/AppData/Local/Programs/Python/Python310:/c/Users/10064957/AppData/Local/Microsoft/WindowsApps:/c/Users/10064957/AppData/Local/Programs/Microsoft VS Code/bin:/c/Users/10064957/.dotnet/tools:/c/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/MSBuild/Current/Bin:/c/Users/10064957/AppData/Local/GitHubDesktop/bin:/c/Users/10064957/OpenBB/OpenBBTerminal.exe:/c/texlive/2023/bin/windows:/c/Program Files/GTK3-Runtime Win64/bin:/c/Users/10064957/AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin:/c/Users/10064957/AppData/Local/Programs/Ollama:/c/Python311/Lib/site-packages/PySpice/Spice/NgSpice/Spice64_dll/dll-vs:/c/ta-lib/c/lib:/c/Users/10064957/AppData/Roaming/npm:/c/Users/10064957/AppData/Local/Programs/Windsurf/bin:/c/Users/10064957/go/bin:/c/mingw64/bin:/c/ffmpeg/bin:/c/Program Files/GitHub CLI'
