# System Configuration & Environment

## Native File Reading Tools

**CRITICAL**: Always use Claude Code's native Read tool for viewing files. NEVER suggest Python or other parsing methods when the Read tool supports the file type.

**Supported file types with Read tool:**
- ✅ **PDF files** (.pdf) - Full text and visual extraction, page by page
- ✅ **Images** (.png, .jpg, .jpeg, .gif, etc.) - Visual analysis with multimodal capabilities
- ✅ **Jupyter notebooks** (.ipynb) - All cells with outputs, code, text, and visualizations
- ✅ **Text files** (.txt, .md, .csv, .json, .xml, .html, .css, .js, .py, etc.)
- ❌ **Excel files** (.xlsx, .xls) - Currently not supported, use Python with zipfile/xml parsing
- ❌ **Word documents** (.docx) - Currently not supported
- ❌ **PowerPoint files** (.pptx) - Currently not supported

**Decision tree for file reading:**
1. ✅ Try Read tool FIRST for all file types
2. ✅ If Read tool fails with "binary file" error, then use appropriate parsing method
3. ❌ NEVER suggest Python parsing without first attempting Read tool

**Examples:**
```bash
# ✅ CORRECT - Try Read tool first
Read tool with file path

# ❌ WRONG - Don't immediately suggest Python
"Let me use Python to parse this Excel file..."
```

## Timezone
**IMPORTANT**: User is on **SAST (South African Standard Time) +2 hours UTC**

### Impact on Outlook Integration
When working with Outlook calendar meetings and emails:
- Outlook COM API returns times in UTC (+00:00 timezone)
- Display times in Outlook UI are converted to local SAST (+2) by Windows
- When specifying meeting times via CLI, use the **local SAST time** (what you see in Outlook calendar)
- The delete-meeting and create-meeting commands accept local SAST times
- Internal processing normalizes to UTC for comparison with stored values

**Example**:
- Outlook UI shows: 15:00 (3 PM SAST)
- Stored in COM API: 13:00 UTC
- To delete: use `--start "2025-10-25 15:00"` (local time as displayed)
- The script handles the UTC conversion internally

### Background Execution for Outlook Operations
When using the outlook-extractor skill, **always run data extraction operations in the background** using `run_in_background: true`:

**Commands to background:**
- `python outlook_extractor.py emails*` - Always background
- `python outlook_extractor.py calendar*` - Always background
- `python outlook_extractor.py contacts*` - Always background
- `python outlook_extractor.py search-contact*` - Always background

**Commands to run synchronously:**
- `python outlook_extractor.py send-email*` - Never background (requires user approval first)
- `python outlook_extractor.py create-meeting*` - Never background (requires user approval first)
- `python outlook_extractor.py delete-meeting*` - Never background (requires user approval first)

This allows the user to continue working while email/calendar extraction completes in the background.

### Outlook Extractor Script Path
**CRITICAL**: When invoking outlook-extractor skill, always use this absolute path:
```
C:\Users\10064957\.claude\skills\outlook-extractor\scripts\outlook_extractor.py
```

**Never use relative paths** - this causes "file not found" errors. Always `cd` to the scripts directory first:
```bash
cd "C:\Users\10064957\.claude\skills\outlook-extractor\scripts"
python outlook_extractor.py <command> [options]
```

### Multiple Email Recipients
**CRITICAL**: When sending emails to multiple recipients, use **COMMAS** to separate email addresses (NOT semicolons).

**Correct syntax:**
```bash
--to "user1@company.com,user2@company.com"
--cc "user3@company.com,user4@company.com,user5@company.com"
```

**Incorrect syntax (will fail):**
```bash
--to "user1@company.com;user2@company.com"  # ❌ WRONG - semicolons don't work
--cc "user3@company.com;user4@company.com"  # ❌ WRONG
```

**Example:**
```bash
python outlook_extractor.py send-email \
  --to "Rudi.Opperman@assmang.co.za" \
  --cc "Jacques.Breet@assmang.co.za,Xavier.Petersen@assmang.co.za,Roelie.Prinsloo@assmang.co.za" \
  --subject "Subject" \
  --body "Message"
```

**Tested and confirmed**: 2025-10-29

---

# Custom Audio Tools

## Split-Audio PowerShell Script
When user requests audio file splitting, use this PowerShell script:

```powershell
param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$InputFile,
    
    [Parameter(Mandatory=$true, Position=1)]
    [int]$NumParts
)

function Show-Usage {
    Write-Host "Usage: .\Split-Audio.ps1 `"filename.mp3`" number_of_parts"
    Write-Host "Example: .\Split-Audio.ps1 `"DiscEnq.Redgie9.MP3`" 3"
    Write-Host ""
    Write-Host "This tool splits an audio file into equal parts using ffmpeg"
}

if (-not $InputFile -or -not $NumParts) {
    Show-Usage
    exit 1
}

if ($NumParts -lt 2) {
    Write-Host "Error: Number of parts must be 2 or greater"
    exit 1
}

if (-not (Test-Path $InputFile)) {
    Write-Host "Error: File '$InputFile' not found"
    exit 1
}

try {
    $null = & ffmpeg -version 2>$null
} catch {
    Write-Host "Error: ffmpeg not found. Please install ffmpeg first."
    exit 1
}

Write-Host "Splitting '$InputFile' into $NumParts parts..."
Write-Host ""

$duration = & ffprobe -i $InputFile -show_entries format=duration -v quiet -of csv="p=0"
$durationFloat = [float]$duration
$partDuration = [math]::Floor($durationFloat / $NumParts)

Write-Host "Total duration: $duration seconds"
Write-Host "Each part will be approximately: $partDuration seconds"
Write-Host ""

$fileInfo = Get-Item $InputFile
$filename = $fileInfo.BaseName
$extension = $fileInfo.Extension

for ($i = 1; $i -le $NumParts; $i++) {
    $startTime = $partDuration * ($i - 1)
    $outputFile = "$filename" + "_part$i" + "$extension"
    
    if ($i -eq $NumParts) {
        Write-Host "Creating part $i`: $outputFile (from $startTime seconds to end)"
        & ffmpeg -i $InputFile -ss $startTime -c copy $outputFile -y -v quiet
    } else {
        $endTime = $startTime + $partDuration
        Write-Host "Creating part $i`: $outputFile (from $startTime to $endTime seconds)"
        & ffmpeg -i $InputFile -ss $startTime -t $partDuration -c copy $outputFile -y -v quiet
    }
}

Write-Host ""
Write-Host "Split completed! Created $NumParts parts:"
for ($i = 1; $i -le $NumParts; $i++) {
    $outputFile = "$filename" + "_part$i" + "$extension"
    Write-Host "- $outputFile"
}
```

Usage: `.\Split-Audio.ps1 "filename.mp3" number_of_parts`
Requirements: ffmpeg installed

# Google Sheets Integration

## Overview
Successfully implemented Google Sheets integration for logging data to a History tracking sheet.

## Files Created
- **Script**: `C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\sheets_writer.py`
- **Dependencies**: `C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\requirements.txt`
- **Setup Guide**: `C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\SETUP.md`
- **Credentials**: `C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\credentials.json`

## Slash Commands
- **`/log-sheet`**: General command to log entries to Google Sheets History tracker
- **`/log-to-sheets`**: Legacy command (use /log-sheet instead)

## Google Sheet Details
- **Sheet ID**: `1JUBWi2-GjyLbonqRPC8TfMy59zKwSSn1hMVC9xGUsfE`
- **Sheet Name**: `History`
- **Headers**: id, subject, date, fileName, transcription, correctedTranscription, changelog, summary, options

## Usage Examples
```bash
# Command line usage
cd "C:\Users\10064957\Documents\OneDrive\AI Projects\Martha"
python sheets_writer.py --mock
python sheets_writer.py --subject "Meeting Title" --summary "Brief summary"
python sheets_writer.py --json '{"subject":"Title","summary":"Summary"}'

# Claude Code slash commands
/log-sheet Weekly team meeting discussed project timeline
/log-sheet Client presentation - high priority
/log-sheet Code review session - internal
```

## Authentication
- Uses OAuth2 desktop application credentials
- Project: `sheetupdaterapp`
- First run requires browser authorization
- Token stored in `token.json` for subsequent runs

## Dependencies Installed
- google-auth-oauthlib
- google-auth-httplib2  
- google-api-python-client

# WhatsApp MCP Integration

## Overview
WhatsApp MCP server integration for sending messages and automating WhatsApp communications directly from Claude Code.

## Bridge Connection Issues - Fix Applied

**Problem:** "Client outdated (405)" error on bridge startup

**Solution (Nov 11, 2025):** Session store corrupted and was cleared. Bridge rebuilt successfully.

**To Restart:**
```bash
cd C:\whatsapp-mcp\whatsapp-bridge
START_BRIDGE.bat
```

This automatically cleans old sessions and authenticates fresh. If error returns, delete `store/` directory and run `START_BRIDGE.bat` again.

**Full Details:** See `C:\whatsapp-mcp\WHATSAPP_BRIDGE_FIX.md`

## System Maintenance & Monitoring

**Location:** `C:\whatsapp-mcp\system-maintenance\`

### Automated Health Checks
Claude Code can run periodic maintenance checks on the WhatsApp bridge to ensure it stays healthy and up-to-date.

**Weekly Health Check (Run every Monday):**
```powershell
cd C:\whatsapp-mcp\system-maintenance
powershell -ExecutionPolicy Bypass -File weekly-health-check.ps1
```

**What it checks:**
- ✅ Bridge process status and memory usage
- ✅ REST API health (localhost:8080)
- ✅ Whatsmeow dependency version (alerts if >30 days old)
- ✅ Database integrity (whatsapp.db, messages.db)
- ✅ Windows Defender exclusions
- ✅ Binary age and build date

**Claude Code Integration:**
When user requests "run WhatsApp maintenance checks" or "check WhatsApp health", execute the weekly-health-check.ps1 script and report findings.

**Alert Thresholds:**
- 🔴 **Critical** (immediate action): Bridge offline, API down, database corruption, whatsmeow >90 days old
- ⚠️ **Warning** (review within 24h): High memory (>500MB), whatsmeow >30 days old, large database (>500MB)
- ✅ **Pass**: All checks within acceptable ranges

**Maintenance Documentation:**
- `TROUBLESHOOTING_LOG.md` - Complete log of all issues and resolutions
- `MAINTENANCE_ROUTINE.md` - Detailed weekly/monthly procedures
- `maintenance-tracker.json` - Automated tracking of check history and metrics

**Next Scheduled Checks:**
- Weekly: November 18, 2025
- Monthly Comprehensive: December 2, 2025

## Configuration Files
- **Global MCP Config**: `C:\Users\10064957\.mcp.json`
- **Local Settings**: `C:\Users\10064957\.claude\settings.local.json`
- **Server Path**: `C:/whatsapp-mcp/whatsapp-mcp-server`
- **Runtime**: Uses `uv` package manager to run Python-based MCP server

## MCP Server Configuration
```json
{
  "mcpServers": {
    "whatsapp": {
      "command": "uv",
      "args": [
        "--directory",
        "C:/whatsapp-mcp/whatsapp-mcp-server",
        "run",
        "main.py"
      ]
    }
  }
}
```

## Usage Examples
Once the MCP server is connected, available WhatsApp tools include:
- **Send Message**: Send text messages to WhatsApp contacts
- **Send Media**: Send images, documents, or other media files  
- **Manage Contacts**: Access WhatsApp contact list
- **Group Messaging**: Send messages to WhatsApp groups

## Daily Production Reports Integration
- **Production Engineering Group**: `27834418149-1537194373@g.us`
- **Processing Priority**: Direct paste → WhatsApp group → Inbox fallback (with cleanup)
- **Time Window**: Check messages from last 24 hours (focus on 06:30-07:30 morning reports)
- **Site Detection**: Look for headers containing "Nchwaning 2", "N2", "Nchwaning 3", "N3", "Gloria", "S&W"
- **Template Compliance**: All reports must conform to Report Templates (Standard Mine Site & Shafts & Winders)
- **Content Style**: Factual reporting only - NO analysis, interpretation, or commentary

## Authentication
- Requires WhatsApp Web session to be active
- Uses web-based WhatsApp API integration
- First run may require QR code scanning for authentication

## Dependencies
- Python-based MCP server
- uv package manager
- WhatsApp Web connectivity
- Active WhatsApp account

## Troubleshooting
- Ensure WhatsApp Web is accessible in browser
- Check that uv is installed and accessible
- Verify MCP server path exists: `C:/whatsapp-mcp/whatsapp-mcp-server`
- Restart Claude Code if MCP tools don't appear

# Important Instruction Reminders
Do what has been asked; nothing more, nothing less.
NEVER create files unless they're absolutely necessary for achieving your goal.
ALWAYS prefer editing an existing file to creating a new one.
NEVER proactively create documentation files (*.md) or README files. Only create documentation files if explicitly requested by the User.
- Xavier is the engineer in charge of shafts and winders.He sends regular messages relating to key projects that we are currently running at Nchwaning 2 shaft.
- when i ask you to send a message, i would like to review it first unless i explicitly state that you can send it without me reviewing
- always ask first before sending a whatsapp message to someone
- always ALWAYS When requested to write a WhatsApp message, first compile a draft first and then ask me permission to send it.
- Always remember when you find a note with a tag "@Claude", Take it as an instruction for you(Claude Code)  to do something. Like, for example, send a WhatsApp message or draft a response, or whatever the instruction or request might be. It will be a direct instruction for you to do.
- remember what skills are and how it is created
- add the above to claude memory

---

# Week 19 Report Generation - Learnings and Error Handling

## Errors/Issues Encountered and Solutions

### 1. **Outlook Folder Navigation Issue**
**Error**: Initial attempt to find OEM/Epiroc folders failed with "OEM folder not found"
**Root Cause**: Used incorrect path syntax with backslashes in Python strings without raw string prefix
**Solution**:
- Use raw string literals `r"path"` for Windows paths with backslashes
- Recursively search for folders by name instead of hardcoding paths
- The actual folder structure is: `Inbox > OEMs > Epiroc` (not `Inbox > OEM > Epiroc`)
**Lesson**: Always list top-level folders first to verify actual structure before searching

### 2. **File Naming Pattern Mismatch**
**Error**: Extraction scripts couldn't find downloaded Excel files (N2, Gloria)
**Root Cause**: Outlook downloads files with "Copy of" prefix (e.g., "Copy of Nch2 Weekly Report...xlsx") but extraction scripts expected exact names without prefix
**Solution**: Rename files after download to remove "Copy of" prefix using `mv` command
**Prevention**: Document expected file naming patterns in skill documentation
**Lesson**: File naming patterns are critical for glob-based file discovery in extraction scripts

### 3. **Unicode/Charmap Encoding Errors**
**Error**: `'charmap' codec can't encode character '\u2713' in position 0: character maps to <undefined>`
**Impact**: Appeared 8+ times during various Outlook operations (email downloads, attachment processing)
**Root Cause**: Windows console using charmap encoding trying to display Unicode checkmarks (✓) and other special characters
**Solution**:
- Error is display-only, not operational - files are still saved successfully
- Can suppress by redirecting stderr or using UTF-8 encoding context
- Is not a blocker - safe to ignore when files are confirmed to exist
**Lesson**: Outlook COM API operations often encounter encoding issues with filenames containing special characters; verify files exist rather than relying on error-free console output

### 4. **BEV Data Extraction Week Selection Mistake**
**Error**: Initial extraction created BEV CSVs but without proper Week 19 selection in Excel pivot table dropdowns
**Root Cause**: Didn't explicitly confirm pivot table was filtered to Week 19 before extraction
**Solution**: User requested redo with explicit week selection: `python extract_bev_data.py --week=19`
**Prevention**:
- Add verification step in extract-bev skill to confirm pivot table filter state
- Document that Excel pivot tables must be manually filtered to target week before export
- Add validation output showing which week was selected
**Lesson**: Pivot table-based extractions require manual Excel interaction; verify source data is filtered correctly before processing

### 5. **Missing File Format Specification**
**Error**: When searching for Epiroc report, first search looked for files with PDF/image extensions but report was in unspecified format
**Root Cause**: Assumed file format without user confirmation
**Solution**: Asked user for clarification ("it is from phillip moller" and "it came in at 10h28 this morning in \OEM\Epiroc folder")
**Lesson**: When file location is provided but format unclear, ask for clarification instead of guessing

### 6. **Folder Path Confusion (OEMs vs OEM)**
**Error**: Initially searched for "OEM" folder, but actual folder name is "OEMs" (plural)
**Root Cause**: Made assumption about folder naming convention without verifying
**Solution**:
- List all top-level folders in Inbox first
- Search by listing actual names: Found folders included "OEMs", "Epiroc", "Production", etc.
- User then clarified: "Its \Inbox\OEMs"
**Lesson**: Always enumerate actual folder names before searching; don't assume naming patterns

### 7. **Incomplete Folder Structure Understanding**
**Error**: Spent time searching in `\Inbox\OEMs\Epiroc` before realizing Epiroc reports are filed in `\Inbox\OEMs\Epiroc` (the structure was correct, just needed better navigation)
**Root Cause**: Didn't properly navigate folder hierarchy with recursive depth control
**Solution**: Implemented recursive folder search with depth limiting to avoid infinite recursion
**Lesson**: Use recursive functions with explicit depth limits when navigating unknown folder structures

### 8. **Outlook Attachment Download Errors Don't Prevent Save**
**Error**: Multiple "charmap codec can't encode" errors during attachment.SaveAsFile() operations
**Expected Behavior**: Errors suggest failure, but files are actually saved successfully
**Verification**: Confirmed files exist in Week 19 directory despite console errors
**Lesson**: For Outlook COM API operations, verify file existence rather than trusting error messages - encoding errors are often cosmetic

### 9. **Email Search Takes Time**
**Pattern**: Background searches (bash IDs 167e0f, 1a1675) ran for extended periods searching through large email folders
**Optimization**: Implement more specific search criteria:
- Include date filters (e.g., last 2-3 hours for recent reports)
- Search by sender name first to narrow scope
- Limit result sets with `limit` and `offset` parameters
**Lesson**: Email searches on large mailboxes can be slow; apply filters before searching

### 10. **BEV Data - Manual Skill Invocation Needed**
**Learning**: The extract-bev skill requires manual selection of Week 19 in Excel pivot tables
- Cannot be fully automated without direct Excel automation
- User must open BEV_Dataset.xlsx and select Week 19 from dropdown before running skill
- Skill then extracts from the filtered data
**Lesson**: Skills that depend on Excel pivot tables have automation limits; document manual steps required

---

## Best Practices Established

### Outlook Folder Navigation
```python
# DO: List actual folder structure first
for folder in inbox.Folders:
    print(f"- {folder.Name}")

# DON'T: Assume folder names or paths
# DON'T: Use backslash in regular strings (use r"" or forward slashes)
```

### File Download and Verification
```python
# DO: Handle Unicode filename issues gracefully
try:
    attachment.SaveAsFile(output_path)
except UnicodeEncodeError:
    # Use sanitized filename as fallback
    safe_filename = "Safe_Name.ext"
    attachment.SaveAsFile(safe_path)

# DO: Verify files exist after download
if os.path.exists(output_path):
    print(f"✓ File verified: {output_path}")
```

### Email Search Strategies
```python
# DO: Use multiple search criteria
- Search by sender name first
- Apply date filters for recent emails
- Limit results to manageable set
- Iterate through results instead of loading all at once

# DON'T: Search all emails without filters on large mailboxes
# DON'T: Assume first result is the one you want
```

### Pivot Table-Based Extraction
```python
# DO: Document manual steps
# 1. User opens BEV_Dataset.xlsx
# 2. User selects Week N from pivot table dropdown
# 3. User exports/saves the file
# 4. Script extracts from filtered data

# DON'T: Assume Excel sheets are pre-filtered
# DON'T: Try to automate Excel pivot table operations without Excel automation library
```

---

## Future Session Improvements

1. **Add Pivot Table Verification**: Modify extract-bev skill to read and report current filter state before extraction
2. **Implement Time-Based Email Filters**: Add `--since` and `--until` parameters to email searches to speed up lookups
3. **Create Folder Navigation Helper**: Build reusable function that maps Outlook folder structure and caches result
4. **Improve Attachment Download Resilience**: Wrap all SaveAsFile operations in try-except with UTF-8 filename sanitization
5. **Document Expected File Names**: Create reference table of exact filenames expected by each extraction skill
6. **Add Pre-Flight Checks**: Before starting week extraction, verify all source files exist with expected names in Week N directory
7. **Create Email Source Map**: Document where each report comes from (sender, folder path, typical arrival time):
   - N2: Sikelela Nzuza → \Inbox\Production\N2
   - N3: Joyce Diale → \Inbox\Planners or \Inbox\Production\NCH3
   - Gloria: Jade Kruger → \Inbox\OEMs\Gloria
   - S&W: Xavier Petersen → Direct email or \Inbox\Production\Shafts
   - Epiroc BEV: Phillip Moller → \Inbox\OEMs\Epiroc (typically 10:28 AM)

---

## Performance Notes

- **Email searching**: Large mailbox searches can take 30+ seconds; use background execution
- **File downloads**: Attachment downloads are sequential; 2 attachments ~2 seconds
- **Excel extraction**: Depends on file size; typically 1-2 seconds per site
- **PDF extraction**: Epiroc PDF processing time varies; typically 5-10 seconds

---

## Known Limitations

1. **Pivot Tables**: Cannot be automated without Excel COM automation; requires manual user interaction
2. **Charmap Errors**: Cannot fully suppress; recommend ignoring if files verify as created
3. **Folder Search**: Recursive search is thorough but slower on large mailboxes; use depth limiting
4. **Encoding Issues**: Some Outlook filename characters will cause console display errors; always verify with `os.path.exists()`

---

# Week 20 Report Generation - Issues and Solutions

## Issues Encountered and Fixes Implemented

### 1. **Email Search - Wrong N2 Report Downloaded**
**Issue:** weekly-report-setup matched "RE: NCH2 Mobilaris Report" instead of actual weekly report
**Root Cause:** Subject keyword "nch2" matched reply/forward chains about system issues
**Solution Implemented:**
- Added `exclude_keywords` parameter to N2 sender configuration
- Now excludes emails containing: 'mobilaris', 're:', 'fwd:'
- Added `preferred_folders` hint: ['Production\\NCH2', 'Production', 'Planners']
**Files Modified:** `.claude\skills\weekly-report-setup\weekly_report_setup.py`
**Status:** ✅ Fixed - Will be effective from Week 21

### 2. **File Naming - "Copy of" Prefixes**
**Issue:** Outlook SaveAsFile() adds "Copy of" prefix for duplicate filenames
**Impact:** Extraction scripts couldn't find files with unexpected prefixes
**Solution Implemented:**
- Added `cleanup_downloaded_files()` function to weekly-report-setup
- Automatically removes "Copy of " prefix after all downloads complete
- Updates internal file tracking list
**Files Modified:** `.claude\skills\weekly-report-setup\weekly_report_setup.py`
**Status:** ✅ Fixed - Automatic cleanup now runs after Step 3

### 3. **Shafts & Winders Availability - Hardcoded Row Numbers**
**Issue:** Script looked for data at row 168, but Week 20 data was at row 158
**Root Cause:** Excel file structure varies between weeks
**Solution Implemented:**
- Added `find_availability_section()` function that searches for "DAY" header
- Dynamically locates data row (2 rows below "DAY" header)
- Searches rows 120-180 instead of assuming fixed location
- Defaults equipment name to "RW" if cell contains time value
**Files Modified:** `.claude\skills\extract-shafts-winders\extract_shafts_winders.py`
**Status:** ✅ Fixed - Now works with any row location

### 4. **PowerPoint File Naming Variations**
**Issue:** Downloaded PPTX files had unexpected names:
- "HEAL page (003).pptx - AutoRecovered.pptx"
- Names didn't match extraction skill glob patterns
**Workaround:** Manual file renaming required
**Future Fix:** Add filename normalization to cleanup function
**Status:** ⚠️ Partially addressed - Manual intervention still needed

### 5. **Epiroc BEV Report Not Found**
**Issue:** Email search didn't find Phillip Moller's BEV report
**Possible Causes:**
- Email received outside Friday-Monday search window
- Email in unexpected folder location
**Workaround:** Manual PDF upload to Week 20 folder
**Status:** ⚠️ Requires investigation - May need wider search window

---

## Improvements Implemented (Week 20 Session)

### Priority 1 Fixes (Completed)

1. **✅ Automatic "Copy of" Removal**
   - Function: `cleanup_downloaded_files()`
   - Runs automatically after Step 3 (downloads)
   - No manual intervention required

2. **✅ N2 Email Search Enhancement**
   - Exclude keywords: mobilaris, re:, fwd:
   - Folder hints for prioritized search
   - Prevents wrong email matches

3. **✅ Dynamic Row Detection for S&W**
   - Searches for "DAY" header instead of hardcoded row
   - Adapts to varying Excel structures
   - Provides clear error messages if section not found

### Validation Recommendations

**For Week 21, verify:**
- [ ] N2 report found correctly (not Mobilaris email)
- [ ] No "Copy of" prefixes in downloaded files
- [ ] S&W availability CSV has data (not empty)
- [ ] All extraction scripts run without manual file renaming

---

## Known Remaining Issues

1. **PowerPoint Filename Normalization** - Still requires manual renaming
2. **Epiroc Search Window** - May need extended date range (investigate arrival patterns)
3. **Unicode Console Errors** - Cosmetic only, does not affect functionality

---

## Documentation Gaps to Address

- [ ] Create email source reference card listing sender, folder, and typical arrival times
- [ ] Document exact filenames expected by each extraction script
- [ ] Add pre-flight checklist for weekly report generation
- [ ] Create troubleshooting flowchart for common Outlook navigation errors
- [ ] Document which operations support background execution vs require synchronous execution

---

# Week 21 Report Generation - Issues and Solutions

## Issues Encountered and Fixes Implemented

### 1. **Epiroc Email Attachment Download Failure**
**Issue:** weekly-report-setup skill detected Epiroc email but skipped attachments as "inline images"
**Root Cause:** Outlook attachment classification marked non-image attachments as inline content when embedded in email body
**Solution Implemented:**
- Created targeted Python script to directly access Outlook COM API
- Forced download of ALL attachments regardless of inline classification
- Successfully downloaded "BRMO weekly report 15 November 2025 - 21 November 2025.pdf" (395KB)
- Identified that Outlook-generated temporary image (Outlook-jxnzcdic.png) can be safely deleted
**Files Modified:** None - Used direct COM API approach
**Status:** ✅ Fixed - Epiroc PDF now successfully downloaded to Week 21

### 2. **Extract-Epiroc-BEV-Report Skill Dependency Issue**
**Issue:** extract_epiroc_bev_report.py script requires Claude Code's native PDF reading capability
**Root Cause:** Script cannot parse PDFs independently; relies on slash command invocation
**Solution Implemented:**
- Used Read tool (native PDF reader) to directly read PDF file
- Manually extracted sections according to skill specification:
  - General Summary
  - BEV Daily Exceptions (filtered - ONLY equipment with breakdowns)
  - Planned Work & Maintenance Schedule
  - Battery and Charger Status Report with full table
  - Battery Overheat Report
  - Critical Issues (BEV, CAS L9, Certiq & Mobilaris)
- Created Epiroc_BEV_Weekly_Report_Week21_Extracted.md with all structured data
**Files Created:** `Week 21/Epiroc_BEV_Weekly_Report_Week21_Extracted.md`
**Status:** ✅ Fixed - Manual extraction method used successfully

### 3. **Outlook Folder Structure Clarification**
**Issue:** Initial confusion about folder path - is it \Inbox\OEM\ or \Inbox\OEMs\?
**Root Cause:** Mixed terminology in instructions and code
**Solution Clarified:**
- Confirmed correct structure: `\Inbox\OEMs\Epiroc` (plural "OEMs")
- weekly-report-setup skill correctly searches for OEMs folder
- Folder navigation confirmed working properly
**Status:** ✅ Clarified - Documented correct path

---

## Improvements to Implement for Future Weeks

### Priority 1 - Epiroc Email Download Automation
**Action:** Update weekly-report-setup skill to force download all Epiroc attachments
- Modify attachment filtering logic to include "inline" classified attachments
- Add fallback: If filtered download fails, attempt unfiltered download
- Target: Week 22+ reports
**Impact:** Eliminates manual COM API script workaround needed in Week 21

### Priority 2 - Extract-Epiroc-BEV-Report Skill Enhancement
**Option A (Recommended):** Create wrapper script that:
- Uses Python with Claude's PDF reading via MCP
- Automatically extracts sections when invoked via slash command
- Outputs markdown file directly

**Option B (Alternative):** Document manual extraction process:
- Add step-by-step guide to skill documentation
- Create extraction checklist to ensure all sections captured
- Provide markdown template for consistency

**Target:** Implement Option A for Week 22+

### Priority 3 - Email Source Reference Card
**Create:** New document listing all weekly email sources:

| Report | Sender | Email | Folder | Subject Keywords | Typical Time | Notes |
|--------|--------|-------|--------|------------------|--------------|-------|
| N2 | Sikelela Nzuza | Sikelela.Nzuza@assmang.co.za | Production\NCH2 | weekly report, eng report, nch2 | Fri-Mon | Exclude: mobilaris, re:, fwd: |
| N3 | Sello Sease | Sello.Sease@assmang.co.za | Production\NCH3 | weekly report, eng report, nch3 | Fri-Mon | |
| Gloria | Sipho Dubazane | Sipho.Dubazane@assmang.co.za | Production\Gloria | weekly report, eng report, gloria | Fri-Mon | |
| Shafts & Winders | Xavier Petersen | Xavier.Petersen@assmang.co.za | Production\Shaft | weekly report, shafts, winders, s&w | Fri-Mon | |
| Epiroc BEV | Phillip Moller | phillip.moller@epiroc.com | OEMs\Epiroc | weekly report, brmo, bev | Mon 07:09 | **IMPORTANT:** First arrival 07:09 AM Monday |

**Status:** 📋 To implement for Week 22+

---

## Key Learnings from Week 21

1. **Outlook Attachment Classification:** Not all attachments are correctly classified as "inline" vs "file". PDF reports may be marked inline but still need downloading.

2. **Epiroc Report Timing:** Phillip Moller consistently sends report Monday morning at 07:09 AM (SAST). Email arrives in \Inbox\OEMs\Epiroc folder.

3. **Extraction Flexibility:** When skills have dependencies on Claude Code features unavailable in pure Python, manual extraction using Read tool is efficient alternative.

4. **PDF Extraction:** Claude's native Read tool successfully extracts PDF content for processing - no special library needed.

5. **Folder Structure:** Always verify actual folder names before searching - use --list-folders to confirm exact structure.

---

## Validation Checklist for Week 21

- [x] Epiroc email found in \Inbox\OEMs\Epiroc folder
- [x] PDF attachment successfully downloaded
- [x] All sections extracted from PDF
- [x] Markdown file created with proper formatting
- [x] BEV Daily Exceptions filtered (only breakdowns/delays included)
- [x] Battery table formatted correctly
- [x] Critical Issues from all three sections captured

---

# Week 23 Report Generation - Issues and Solutions

## Issues Encountered and Resolutions

### 1. **Epiroc Email Search - Date/Timezone Comparison Failures**

**Issue:** Multiple attempts to find Phillip Moller's email using datetime filtering all failed

**Root Causes:**
- Outlook ReceivedTime returns timezone-aware datetime objects (`2025-12-08 05:38:36.790000+00:00`)
- Python `datetime(2025, 12, 8)` creates naive datetime objects
- Comparison between timezone-aware and naive datetimes fails silently

**Failed Attempts:**
```python
start_date = datetime(2025, 12, 8)  # Failed - naive vs aware comparison
start_date = datetime(2025, 12, 7)  # Still failed - same issue
```

**Solution Implemented:**
- **REMOVED date filtering entirely** from email search
- Used subject/sender keyword matching instead:
```python
if ('phillip' in sender_lower or 'moller' in sender_lower) and 'weekly report' in subject_lower and '28nov' in subject_lower:
```

**Lesson:** For recent email searches, use **keyword matching** instead of datetime comparisons. Timezone-aware comparisons are unreliable in Outlook COM API.

**Best Practice Going Forward:**
```python
# DO: Use keyword matching for recent emails
if 'sender_name' in sender_lower and 'subject_keyword' in subject_lower:
    # Process email

# DON'T: Use datetime comparison with Outlook ReceivedTime
if item.ReceivedTime > start_date:  # ❌ Fails with timezone issues
```

---

### 2. **Search Strategy Overcomplicated - Should Use outlook-extractor Skill First**

**Issue:** Created multiple custom Python scripts for Outlook navigation when simpler solution existed

**Custom Scripts Created (Unnecessarily):**
- `download_epiroc_final.py`
- `search_missing_emails.py`
- `search_planners_all.py`
- Multiple debug/listing scripts

**User Feedback:** *"the emails came in this morning. you have done this many times before without problems. there is a outlook extractor skills that you use"*

**Solution:** Should have started with outlook-extractor skill:
```bash
cd "C:\Users\10064957\.claude\skills\outlook-extractor\scripts"
python outlook_extractor.py emails --days 1 --folder-search "Epiroc"
```

**Lesson:** **ALWAYS use outlook-extractor skill FIRST** before writing custom Outlook scripts. Only create custom scripts if outlook-extractor doesn't support the use case.

**Decision Tree:**
1. ✅ Try outlook-extractor skill first
2. ✅ If it fails, ask user for clarification
3. ❌ DON'T immediately write custom COM API scripts

---

### 3. **File Creation - Write Tool Permission Error**

**Issue:** Attempted to Write to non-existent file failed with: *"File has not been read yet. Read it first before writing to it."*

**Root Cause:** Write tool requires files to exist and be read first

**Failed Bash Attempts:**
```bash
echo. > file.md          # ❌ bash doesn't have echo. (Windows CMD only)
type nul > file.md       # ❌ bash doesn't have type command
```

**Working Solution:**
```bash
touch "file.md"          # ✅ Create empty file
```
Then Read it, then Write to it.

**Lesson:** Use **bash-compatible commands** only. Avoid Windows CMD syntax.

**Reference:**
| Operation | ❌ Windows CMD | ✅ Bash |
|-----------|---------------|---------|
| Create empty file | `echo. > file` | `touch file` |
| List files | `dir /b` | `ls -1` |
| Count lines | `find /c` | `wc -l` |

---

### 4. **Outlook COM API - Slice Iterator Error (Avoided)**

**Known Issue from Previous Sessions:** `for item in items[:20]` causes COM VARIANT error

**Preemptive Solution Used:**
```python
# ✅ CORRECT - Manual counter
shown = 0
for item in items:
    shown += 1
    if shown > 20:
        break

# ❌ WRONG - Slice notation fails with COM objects
for item in items[:20]:  # TypeError: Objects of type 'slice' cannot be converted to COM VARIANT
```

**Status:** Successfully avoided in Week 23 session

---

### 5. **Unicode Encoding Errors (Cosmetic Only - Recurring)**

**Error:** `'charmap' codec can't encode character '\u2713'` during Outlook operations

**Impact:** Display-only errors - **files still save successfully**

**Mitigation:**
```python
sys.stdout.reconfigure(encoding='utf-8')  # Add to all Outlook scripts
```

**Critical Understanding:**
- ✅ Verify file existence with `os.path.exists()`
- ❌ Don't trust console output to determine success/failure
- These errors are **cosmetic only** and can be safely ignored

---

## Key Lessons for Future Weekly Report Sessions

### Email Search Best Practices

1. **Use outlook-extractor skill FIRST**
   ```bash
   python outlook_extractor.py emails --days 1 --folder-search "FolderName"
   ```

2. **Avoid datetime filtering** - use keyword matching instead:
   ```python
   # ✅ Good
   if 'keyword' in subject_lower and 'sender' in sender_lower:

   # ❌ Bad
   if item.ReceivedTime > datetime(2025, 12, 8):
   ```

3. **Specific subject keywords** beat date ranges:
   ```python
   # ✅ Good - specific week identifier
   if 'weekly report' in subject_lower and '28nov' in subject_lower:

   # ❌ Bad - generic match
   if 'weekly report' in subject_lower:
   ```

### Bash Command Compatibility

**Always use bash/Unix commands:**
```bash
touch file.txt        # ✅ Create file
ls -1 *.csv           # ✅ List files
wc -l                 # ✅ Count lines
```

**Never use Windows CMD syntax:**
```bash
echo. > file.txt      # ❌ Fails in bash
dir /b *.csv          # ❌ Fails in bash
type file.txt         # ❌ Fails in bash
```

### Outlook COM API Patterns

**✅ DO:**
```python
# Manual iteration with counter
shown = 0
for item in items:
    shown += 1
    if shown > 20:
        break

# Keyword-based filtering
if 'sender' in sender_lower and 'subject' in subject_lower:
    process_email(item)

# Always verify file existence
if os.path.exists(output_path):
    print(f"✓ File verified")
```

**❌ DON'T:**
```python
# Slice notation on COM collections
for item in items[:20]:  # Fails

# Datetime comparison with ReceivedTime
if item.ReceivedTime > start_date:  # Unreliable

# Trust console errors for file operations
# (Files may save despite encoding errors)
```

### Problem-Solving Decision Tree

When searching for weekly report emails:

```
1. Use outlook-extractor skill
   ├─ Success? → Download files
   └─ Failed? → Continue to 2

2. Check user guidance for folder/sender
   ├─ Clear info? → Use specific search
   └─ Unclear? → Ask user for clarification

3. Use keyword matching (NOT date filtering)
   ├─ Found? → Download
   └─ Not found? → Ask user

4. ONLY create custom script if:
   - outlook-extractor doesn't support use case
   - User provides specific technical requirement
   - Previous approaches exhausted
```

---

## Updated Email Source Reference (Confirmed Week 23)

| Report | Sender | Email | Folder | Subject Pattern | Arrival Time | Search Strategy |
|--------|--------|-------|--------|----------------|--------------|-----------------|
| N2 | Sikelela Nzuza | Sikelela.Nzuza@assmang.co.za | Production\NCH2 | "weekly report", "nch2" | Fri-Mon AM | Exclude: 'mobilaris', 're:', 'fwd:' |
| N3 Excel | Joyce Diale | Joyce.Diale@assmang.co.za | **Planners** | "N3 Eng Report Week", "28 Nov" | Variable | Check Planners folder first |
| N3 HEAL | Sello Sease | Sello.Sease@assmang.co.za | Production\NCH3 | "heal", "n3" | Fri-Mon AM | |
| Gloria Excel | Jade Kruger | Jade.Kruger@assmang.co.za | Production\Gloria | "eng report", "gloria" | Fri-Mon AM | |
| Gloria HEAL | Jade Kruger | Jade.Kruger@assmang.co.za | Production\Gloria | "HEAT" (typo for HEAL) | Fri-Mon AM | Sender calls it "HEAT Report" |
| S&W | Xavier Petersen | Xavier.Petersen@assmang.co.za | Production\Shaft | "weekly report", "shafts" | Fri-Mon AM | |
| **Epiroc BEV** | **Phillip Moller** | phillip.moller@epiroc.com | **OEMs\Epiroc** | "weekly report", "28nov" | **Mon 05:38-07:00 AM** | **Use subject week match, NOT date filter** |

**Critical Notes:**
- **Epiroc**: Arrives early Monday morning (05:38-07:00 AM SAST). Use week identifier in subject ('28nov', '22nov') instead of date filtering.
- **N3 Excel**: May be in `\Inbox\Planners` folder instead of Production\NCH3
- **Gloria HEAL**: Sender calls it "HEAT Report" (typo) - search for "heat" or "heal"

---

## Validation Checklist for Week 23

- [x] All source files downloaded (10 files)
- [x] All data extracted (23 CSV/TXT/MD files)
- [x] Epiroc PDF found using keyword matching (not date filtering)
- [x] N3 Excel found in Planners folder
- [x] Gloria HEAL renamed from "HEAT Report"
- [x] No manual intervention required for file operations
- [x] Unicode encoding errors ignored (files verified by existence check)
- [x] Complete inventory document created

---

## Tools and Techniques Used Successfully

1. **outlook-extractor skill** - Should be first choice for email searches
2. **Read tool for PDF** - Native PDF reading for Epiroc extraction
3. **touch command** - Bash-compatible file creation
4. **Keyword matching** - More reliable than datetime filtering for recent emails
5. **os.path.exists()** - Reliable file verification despite console errors

---

- (entities: [{"name":"Claude Code Skills System","entityType":"System Architecture","observations":["Claude Code Skills are automated extraction and processing tools that can be
                                invoked via slash commands","Skills are located in .claude/skills/ directory with subdirectories for each skill","Each skill encapsulates a specific data extraction or
                                processing task","Skills use Python scripts as the execution backend with documentation overlays","Skills provide a progressive disclosure model: SKILL.md for users,
                                reference.md for technical details"]},{"name":"Skill Directory Structure","entityType":"File Organization","observations":["Each skill has its own directory:
                                .claude/skills/{skill-name}/","Every skill requires three files: SKILL.md, Python script, and reference.md","SKILL.md serves as the user-facing documentation and usage
                                guide","Python script handles all data processing and extraction logic","reference.md contains technical implementation details for developers"]},{"name":"SKILL.md File
                                Format","entityType":"Documentation Template","observations":["First section: YAML front matter with name and description (300 chars max)","Contains user-focused documentation
                                with clear examples and explanations","Starts with 'When to Use This Skill' section for quick identification","Usage section shows both CLI and slash command
                                invocations","Prerequisites section lists required setup steps","Data Extraction section explains what the script does in plain language","Output Files section shows exact CSV
                                naming and location","CSV Structure & Content section documents every column with examples","Site-Specific Data Locations section explains where data comes from in each Excel
                                file","Example Outputs section shows real data samples","Validation Checks section lists quality assurance steps","Common Issues & Troubleshooting section with solutions","Next
                                Steps After Extraction section guides users to next tasks"]},{"name":"Python Script Architecture","entityType":"Implementation Pattern","observations":["Script uses argparse for
                                 both named (--week=16) and positional (16) arguments","Implements helper functions for common tasks: file finding, cell reading, data formatting","Uses zipfile to read Excel
                                files as ZIP archives containing XML","Extracts shared strings for text data and resolves numeric references","Builds cells dictionary with (row_num, col_letter) keys for cell
                                access","Implements site or context-specific column mappings as dictionaries","Handles special cases like Gloria's shared string offset correction (-7)","Formats numeric output:
                                 decimals to 2 places, percentages with % symbol","Generates CSV files in Week X/ folders with consistent naming","Includes detailed error messages for troubleshooting","Returns
                                 exit codes: 0 for success, 1 for failure"]},{"name":"reference.md File Format","entityType":"Technical Documentation","observations":["Implementation Details section explains
                                core logic and approach","File Detection section describes glob patterns used to find Excel files","Sheet Location Resolution section explains XML parsing and sheet
                                finding","Data Extraction Process section provides detailed breakdowns","Variation Handling section documents how script handles edge cases","Known Issues & Workarounds section
                                documents discovered problems and fixes","CSV Output Format section specifies exact formatting rules","Performance Characteristics section documents speed and
                                scalability","Testing Coverage section lists verified configurations","Future Enhancements section suggests potential improvements"]},{"name":"Excel Data Extraction
                                Process","entityType":"Technical Methodology","observations":["Excel files (.xlsx) are ZIP archives containing XML files and resources","workbook.xml lists all sheets with their
                                 IDs","workbook.xml.rels maps relationship IDs to physical sheet file paths","sharedStrings.xml contains all text values referenced by numeric IDs in cells","Worksheets are in
                                worksheets/sheet*.xml files","Each cell has coordinates (A1, B5, etc.) and contains either text, numbers, or formulas","Cell types: 's' for string (uses shared string ID),
                                numbers stored as decimals","Namespace handling required: main namespace for content, r namespace for relationships"]},{"name":"Shared String Offset Issue
                                (Gloria)","entityType":"Data Corruption Pattern","observations":["Gloria Excel files have systematic shared string reference corruption","All string references are offset by +7
                                beyond valid array indices","Appears to be Excel export system error from source database","Workaround: detect out-of-bounds references, subtract 7 to get correct
                                index","Implementation: if string_idx >= len(strings) and string_idx - 7 >= 0: string_idx -= 7","Affects breakdown/comment columns in extraction but not numeric data","Fully
                                resolved in extract_primary_equipment.py and extract_maintenance_compliance.py scripts"]},{"name":"Column Mapping Pattern","entityType":"Code Design
                                Pattern","observations":["Different sites often have different column layouts for same data types","Define column mappings as dictionaries with semantic keys","Example:
                                {'fleet': 'B', 'planned': 'E', 'actual': 'G', 'reason': 'M'}","Use mapped values to access cells generically: cells_dict.get((row, cols['fleet']))","Allows single script to
                                handle multiple site variations without conditional branching","Easy to update if file structure changes slightly"]},{"name":"Numeric Formatting in CSV","entityType":"Data
                                Formatting Standard","observations":["Production metrics: 2 decimal places, no special formatting (679.79, 523.00)","Percentages: formatted with % symbol, 2 decimal places
                                (99.13%, 100.00%)","Compliance percentages: 1 decimal place (93.4%, 100.0%)","Preserve zero values and empty cells (represent no data, not zero production)","Handle error
                                values: preserve #DIV/0! as-is if present in source","Use Python f-strings: f\"{float_val:.2f}\" for decimals, f\"{float_val:.2f}%\" for percentages"]},{"name":"Error Handling
                                Strategy","entityType":"Quality Assurance","observations":["Check file existence before attempting to open: print clear error to stderr","Validate sheet exists before attempting
                                 data extraction","Provide descriptive error messages: include context like site name and week number","Use stderr for errors, stdout for progress information","Return False on
                                any critical failure, True on success","Exit code 1 for failure, 0 for success (standard Unix convention","Wrap risky operations in try-except blocks with specific error
                                messages"]},{"name":"CSV Writing Best Practices","entityType":"Output Format Standard","observations":["Use csv.writer for standard CSV generation","Encode as UTF-8 for Unicode
                                character support","Header row first with descriptive column names","One data row per extracted entry","Quote only when necessary (special characters, commas, quotes)","Use
                                newline='' parameter for proper line ending handling","Close file explicitly or use context manager (with statement)","Verify file was written before reporting
                                success"]},{"name":"Skill Invocation Methods","entityType":"User Interface","observations":["Claude Code skill syntax: /skill-name arguments","Named arguments: --parameter=value
                                 (Python argparse style)","Positional arguments: values without dashes in order","Examples: /extract-primary-equipment gloria 16 or /extract-primary-equipment --site=gloria
                                --week=16","Skill name must match directory name in .claude/skills/","Python script is the executable for the skill"],"observationss":["Slash command triggers skill
                                execution","Both argument styles must be supported in argparse configuration","Help text shown when arguments are missing or invalid"]},{"name":"Test-Driven Skill
                                Development","entityType":"Development Process","observations":["Start by exploring target Excel file structure with investigative Python scripts","Test data extraction on
                                sample file before finalizing code","Verify output CSV matches expected format and content","Check file locations and naming conventions","Confirm numeric formatting is
                                correct","Test on all variations (different sites, different weeks)","Verify error handling works as documented"]},{"name":"Skills Already
                                Created","entityType":"Inventory","observations":["extract-primary-equipment: Extracts daily equipment availability data (Gloria, N2, N3)","extract-maintenance-compliance:
                                Extracts weekly maintenance service compliance metrics (Gloria, N2, N3)","extract-bev: Extracts Battery Electric Vehicle performance data from
                                BEV_Dataset.xlsx","extract-shafts-winders: Extracts production and equipment availability for shaft/winder systems","All skills follow consistent architecture and patterns","All
                                 skills support both named and positional arguments","All skills generate CSV files in Week X/ directories","All skills include comprehensive documentation"]}])
- The outlook extractor skill etc are located here: C:\Users\10064957\AppData\Local\Microsoft\Outlook