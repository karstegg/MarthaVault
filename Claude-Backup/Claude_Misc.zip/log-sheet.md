# Log to Sheet Command

You are helping the user log data to their Google Sheets History tracker.

## Instructions:
1. Parse the user's input to extract relevant information for the history tracking system
2. Execute the Python script located at: `C:\Users\10064957\Documents\OneDrive\AI Projects\Martha\sheets_writer.py`
3. Use the extracted information to populate the Google Sheet

## Expected fields to extract from user input:
- **subject**: Main topic/title of the entry
- **fileName**: Audio file name (if mentioned)
- **transcription**: Initial transcription text (if provided)
- **correctedTranscription**: Corrected version (if provided)
- **changelog**: Changes made (if provided)
- **summary**: Brief summary of the content
- **options**: Tags, priority level, or categories (e.g., "high_priority", "client_facing", "internal", "humor")

## Usage Examples:
- `/log-sheet Weekly team meeting discussed project timeline and resource allocation`
- `/log-sheet Client presentation about new dashboard features - high priority`
- `/log-sheet Code review session found optimization opportunities in data processing - internal`
- `/log-sheet Daily standup comedy: Why do programmers prefer dark mode? Because light attracts bugs!`

## Script Execution:
Execute the Python script with extracted data:

### For simple entries:
```bash
cd "C:\Users\10064957\Documents\OneDrive\AI Projects\Martha" && python sheets_writer.py --subject "extracted subject" --summary "extracted summary" --options "extracted options"
```

### For complex entries with multiple fields:
```bash
cd "C:\Users\10064957\Documents\OneDrive\AI Projects\Martha" && python sheets_writer.py --json '{"subject":"subject","fileName":"filename.mp3","transcription":"initial text","correctedTranscription":"corrected text","changelog":"changes made","summary":"summary","options":"tags"}'
```

### For adding mock data:
```bash
cd "C:\Users\10064957\Documents\OneDrive\AI Projects\Martha" && python sheets_writer.py --mock
```

## Parsing Guidelines:
- Extract the main topic as the subject
- Look for file references (e.g., "meeting.mp3", "call.wav") as fileName
- Identify priorities or categories (high/medium/low priority, internal/external, client_facing, etc.)
- Create a concise summary of the content
- If it's clearly a joke or humorous content, tag with "humor"

## Response:
After successfully executing the script, confirm to the user that the data has been logged to their Google Sheet with a brief summary of what was added.