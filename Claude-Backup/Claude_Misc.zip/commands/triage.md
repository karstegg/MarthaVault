# /triage
For every file in 00_inbox/:
1. Read its contents.
2. Decide destination folder by looking for lines like
   `project: ...` or obvious keywords.
3. Move file, add missing tags, fix date in filename.
4. If it contains check-boxes, mirror them to master_task_list.md.
Report a summary of moves (old → new path).