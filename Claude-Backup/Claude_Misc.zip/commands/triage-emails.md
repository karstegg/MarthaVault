---
name: triage-emails
description: Daily email triage - analyze sent/inbox with priority folders, cross-reference vault, generate action report
---

# Daily Email Triage Workflow

This command performs end-of-day email analysis to identify action items, status updates, and decisions.

## Process:

### 1. Extract Emails from Priority Folders

**Priority 1 (Highest weight - immediate action)**:
- Inbox (top-level)
- Inbox\Production
- Inbox\Safety & Security
- Inbox\CAS Project

**Priority 2 (Medium weight - important)**:
- Inbox\HR
- Inbox\Finance and Procurement

**Priority 3 (Lower weight - monitor)**:
- Inbox\OEMs
- All other Inbox subfolders

**Sent Items (Context signal)**:
- Shows what user prioritized and responded to

### 2. Cross-Reference with Vault

For each email:
- Search `tasks/master_task_list.md` for related tasks
- Search `projects/` for related projects
- Search `people/` for sender/recipient context
- Query Graph Memory for relationships and strategic alignment
- Query Basic Memory for recent activity context

### 3. Categorize Emails

**ACTION REQUIRED** (User must respond/delegate/create task):
- Direct questions requiring response
- Requests for information or decisions
- Escalations or urgent issues
- Meeting requests needing acceptance/decline

**STATUS UPDATE** (Update existing records):
- Progress reports on active tasks/projects
- Completion notifications
- Changed timelines or schedules
- New information on ongoing work

**FYI ONLY** (Acknowledge but no action):
- Information-sharing emails (CC'd)
- Announcements and notifications
- Automated system emails
- Meeting acceptances/declines from others

**DELEGATED** (Others handling, user monitoring):
- Tasks assigned to engineers
- Work in progress by team members
- Follow-up items with clear owners

### 4. Generate Triage Report

Create `00_inbox/YYYY-MM-DD – Daily Email Triage.md` with:

#### Summary Statistics
- Total emails scanned
- P1/P2/P3 folder breakdown
- Action required count
- Status updates count
- Emails sent count

#### Action Items
For each action-required email:
- **From**: Sender name (link to people file if exists)
- **Subject**: Email subject
- **Folder**: Which priority folder
- **Received**: Timestamp
- **Context**: Related task/project (if found)
- **Recommended Action**: Create task / Draft response / Schedule meeting
- **Draft Response**: If applicable

#### Status Updates Needed
For each status-update email:
- **Related To**: Task/Project link
- **Update**: Summary of new information
- **Action**: What to update (task status, due date, notes, etc.)

#### Sent Email Context
Show what user responded to (priority signal):
- **Sent To**: Recipients
- **Subject**: Email subject
- **Time**: When sent
- **Related To**: Task/project (if found)

### 5. Present for Approval

Ask user to review:
- Proposed task creates
- Draft email responses
- Status update changes
- Any new project creation needs

### 6. Execute Approved Actions

After user approval:
- Create tasks in master_task_list.md
- Send draft email responses
- Update task/project files
- Create new people files if needed

## Usage:

```bash
/triage-emails
```

Run at end of workday (typically 16:00-17:00 SAST).

## Parameters:

None required. Uses default settings:
- **Time window**: Last 24 hours
- **Priority folders**: As defined above
- **Output**: `00_inbox/YYYY-MM-DD – Daily Email Triage.md`

## Output Format:

Markdown file with:
- Executive summary at top
- Action items grouped by priority
- Status updates by project
- Sent emails context
- Approval checklist at bottom

## Next Steps:

1. Review generated triage report
2. Approve/edit/reject suggested actions
3. Execute approved actions via follow-up prompts
4. Archive triage report when complete

---

**Implementation**: This command orchestrates multiple tools (outlook_extractor, Grep, Read, Graph Memory, Basic Memory) to provide comprehensive email context and actionable insights.
