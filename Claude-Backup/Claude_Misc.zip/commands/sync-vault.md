---
description: Sync vault changes to Graph and Basic Memory systems
---

# Vault Sync Command Implementation

## Overview
This command detects all changes to the vault since the last sync checkpoint and automatically updates Graph Memory and Basic Memory systems.

## Execution Steps

### 1. Parse Arguments
- Check for `--full` flag (full re-index)
- Check for `--dry-run` flag (preview only)
- Check for `--verbose` flag (detailed logs)

### 2. Get Changed Files Since Checkpoint
```bash
cd "C:\Users\10064957\My Drive\GDVault\MarthaVault"
checkpoint=$(cat .vault-sync-checkpoint 2>/dev/null || echo "")
current_head=$(git rev-parse HEAD)

if [ -n "$checkpoint" ]; then
    # Standard sync: changes since checkpoint
    changed_files=$(git diff --name-status $checkpoint HEAD)
else
    # No checkpoint: treat as full sync
    changed_files=$(git ls-files)
fi
```

### 3. Filter to Relevant Folders
Keep only files in:
- people/*.md
- projects/**/*.md
- tasks/*.md
- Schedule/*.md
- strategy/*.md
- system/*.md
- IDEAS/*.md
- Operations/**/*.md
- reference/places/**/*.md

### 4. Group by Change Type
- Added (A): New files
- Modified (M): Changed files
- Deleted (D): Removed files

### 5. Process Each File Type

#### ADDED FILES
For each added file:
1. Read file content
2. Extract: title, tags, status, priority, entity type from folder path
3. Create Graph Memory entity with 5-10 key observations
4. Create Basic Memory note with full content
5. Create relations for wikilinks [[Person]] or [[Project]]

**Entity Type Mapping:**
- people/*.md → Personnel
- projects/*/*.md → Project
- tasks/*.md → Task
- Schedule/*.md → Business Process
- strategy/*.md → Strategy
- system/*.md → System Enhancement
- IDEAS/*.md → Idea
- Operations/*/*.md → Project (site-specific)

#### MODIFIED FILES
For each modified file:
1. Read updated content
2. Search Graph Memory for existing entity by name
3. If found: Delete old entity, create new entity with updated observations
4. Update Basic Memory note (overwrites existing)
5. Update relations if wikilinks changed

#### DELETED FILES
For each deleted file:
1. Search Graph Memory for entity by name
2. Delete entity if found
3. Delete Basic Memory note if indexed

### 6. Update Checkpoint
```bash
echo "$current_head" > .vault-sync-checkpoint
```

### 7. Report Summary
Display:
- Last sync timestamp and commit
- Current timestamp and commit
- Count of added/modified/deleted files
- Graph Memory entities created/updated
- Basic Memory notes created/updated
- Completion status

## Important Notes

- **Batch operations**: Process up to 10 entities per API call
- **Parallel reads**: Read multiple files in parallel when possible
- **Error handling**: Log errors but continue processing remaining files
- **Skip on --dry-run**: Don't update checkpoint if --dry-run flag set
- **Target performance**: Complete typical sync (1-10 files) in <5 seconds

## Output Format

```
🔄 Syncing vault to memory systems...

Detected changes:
  Added: X files
  Modified: Y files
  Deleted: Z files

Processing...
  ✅ Graph Memory: N entities created/updated, M relations
  ✅ Basic Memory: P documents indexed

🔄 Checkpoint updated: [commit-sha]
✅ Sync complete (X.Xs)
```
